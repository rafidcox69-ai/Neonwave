import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import { defineConfig, Plugin } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';
import JSZip from 'jszip';

function zipDownloadPlugin(): Plugin {
  return {
    name: 'zip-download-plugin',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (req.url === '/api/download-android-zip') {
          try {
            const zip = new JSZip();
            const rootDir = process.cwd();

            function addDirectory(currentPath: string, zipFolder: JSZip) {
              const items = fs.readdirSync(currentPath);
              for (const item of items) {
                if (['node_modules', '.git', 'dist', 'build', '.gradle'].includes(item)) continue;
                const itemPath = path.join(currentPath, item);
                const stat = fs.statSync(itemPath);
                if (stat.isDirectory()) {
                  addDirectory(itemPath, zipFolder.folder(item)!);
                } else {
                  zipFolder.file(item, fs.readFileSync(itemPath));
                }
              }
            }

            const appDir = path.join(rootDir, 'app');
            if (fs.existsSync(appDir)) {
              addDirectory(appDir, zip.folder('app')!);
            }

            const rootFiles = ['build.gradle.kts', 'settings.gradle.kts', 'README_ANDROID.md'];
            for (const file of rootFiles) {
              const fPath = path.join(rootDir, file);
              if (fs.existsSync(fPath)) {
                zip.file(file, fs.readFileSync(fPath));
              }
            }

            const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
            res.setHeader('Content-Type', 'application/zip');
            res.setHeader('Content-Disposition', 'attachment; filename="NeonWave-Android-Studio-Project.zip"');
            res.setHeader('Content-Length', buffer.length.toString());
            res.end(buffer);
            return;
          } catch (err: any) {
            console.error('Error generating Android zip:', err);
            res.statusCode = 500;
            res.end('Error generating Android zip: ' + err.message);
            return;
          }
        }

        if (req.url === '/api/download-project-zip') {
          try {
            const zip = new JSZip();
            const rootDir = process.cwd();

            function addDirectory(currentPath: string, zipFolder: JSZip) {
              const items = fs.readdirSync(currentPath);
              for (const item of items) {
                if (['node_modules', '.git', 'dist', 'build', '.gradle'].includes(item)) continue;
                const itemPath = path.join(currentPath, item);
                const stat = fs.statSync(itemPath);
                if (stat.isDirectory()) {
                  addDirectory(itemPath, zipFolder.folder(item)!);
                } else {
                  zipFolder.file(item, fs.readFileSync(itemPath));
                }
              }
            }

            addDirectory(rootDir, zip);

            const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
            res.setHeader('Content-Type', 'application/zip');
            res.setHeader('Content-Disposition', 'attachment; filename="NeonWave-Complete-Project.zip"');
            res.setHeader('Content-Length', buffer.length.toString());
            res.end(buffer);
            return;
          } catch (err: any) {
            console.error('Error generating project zip:', err);
            res.statusCode = 500;
            res.end('Error generating project zip: ' + err.message);
            return;
          }
        }

        next();
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      zipDownloadPlugin(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['icon.svg', 'apple-touch-icon.png', 'pwa-192x192.png', 'pwa-512x512.png'],
        manifest: {
          id: '/',
          name: 'NeonWave Offline Music Player',
          short_name: 'NeonWave',
          description: 'A minimalist offline music player with pure black & neon identity, dual queues, lyrics, and smart album folders.',
          theme_color: '#000000',
          background_color: '#000000',
          display: 'standalone',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
        },
        devOptions: {
          enabled: true,
          type: 'module',
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
      },
    },
    server: {
      port: 3000,
      host: '0.0.0.0',
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
