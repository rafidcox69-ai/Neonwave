# NeonWave — Minimal Offline Music Player for Android

Welcome to the native Android source code for **NeonWave**, a pure black & neon minimalist offline music player.

## 📱 Features Included
- **Jetpack Compose UI**: Pure black (`#000000`) background with customizable neon cyan, blue, violet, and green accents.
- **AndroidX Media3 / ExoPlayer**: `NeonWaveMediaService` running as a Foreground Media Service with Android system lock-screen and notification controls.
- **6 Library Sections**: All Songs, Folders, Playlists, Hidden Albums, Most Played, and Not Played for Long Time.
- **Universal Search**: Fast search across all tabs and folders.
- **Synchronized Lyrics**: Real-time `.lrc` timestamped lyrics display and glowing neon lyric indicators.
- **Dual Queues**: Independent Queue A and Queue B.
- **AutoMediaScanner**: `ContentObserver` that detects new audio files in device storage and automatically categorizes them into album folders based on metadata (`Artist — Album`).
- **Room Database**: Persistent storage for play counts, listening history, timestamps, and playlists.

---

## 🛠️ How to Build the APK

### Method 1: Using Android Studio (Recommended)
1. Download and extract this project folder.
2. Open **Android Studio** (Hedgehog, Iguana, Koala, or newer).
3. Select **Open** and choose the extracted `NeonWave` folder.
4. Wait for Gradle sync to complete (requires Android SDK 26+ and JDK 17+).
5. In the top menu, go to:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)**
6. Once built, click **locate** in the popup notification to find `app-debug.apk` (typically located in `app/build/outputs/apk/debug/app-debug.apk`).
7. Copy `app-debug.apk` to your Android device (Samsung Galaxy A06, Pixel, etc.) or connect via USB and click **Run 'app'** (Shift + F10) to install directly!

---

### Method 2: Command Line (Gradle)
Run the following command in the project root:

```bash
# On Linux / macOS:
./gradlew assembleDebug

# On Windows:
gradlew.bat assembleDebug
```

The APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 🌐 Instant Phone Installation (Progressive Web App)
You can also run NeonWave directly on your phone without building an APK:
1. Open the app link in **Chrome** or **Samsung Internet** on your Android device.
2. Tap the browser menu (⋮) and select **Install app** or **Add to Home screen**.
3. NeonWave will be installed as a standalone offline app on your home screen with its custom icon!


## Build an APK using a phone (GitHub Actions)

This project includes `.github/workflows/android-apk.yml`. You can build the APK online without installing Android Studio on your phone:

1. Create/sign in to a GitHub account and create a **new repository**.
2. Upload the contents of this ZIP (extract it first; upload the files and folders, not the ZIP itself) to the repository's `main` branch. Make sure `.github/workflows/android-apk.yml` is included.
3. Open the repository on GitHub in your phone browser, select **Actions**, then **Build NeonWave APK**.
4. Tap **Run workflow** and wait for the run to finish successfully.
5. Open the completed run and download the `NeonWave-debug-APK` artifact. Extract the downloaded artifact ZIP; it contains the APK.
6. Open the APK on your Android phone and allow installation from that source if Android asks.

The workflow builds a **debug APK** for testing. It does not create a Play Store release or guarantee the app has no runtime bugs.
