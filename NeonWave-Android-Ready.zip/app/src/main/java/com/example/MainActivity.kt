package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.ActiveQueue
import com.example.model.Playlist
import com.example.model.Song
import com.example.repository.MusicRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch

enum class MainTab(val title: String) {
    ALL_SONGS("All Songs"),
    FOLDERS("Folders"),
    PLAYLISTS("Playlists"),
    HIDDEN_ALBUMS("Hidden Albums"),
    MOST_PLAYED("Most Played"),
    NOT_PLAYED("Not Played for Long Time")
}

enum class SortMode {
    TITLE_AZ,
    TITLE_ZA,
    RECENTLY_ADDED,
    MOST_PLAYED
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NeonWaveApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NeonWaveApp() {
    val context = LocalContext.current
    val repository = remember { MusicRepository(context) }
    val scope = rememberCoroutineScope()

    var selectedAccent by remember { mutableStateOf(NeonAccent.CYAN) }
    var currentTab by remember { mutableStateOf(MainTab.ALL_SONGS) }
    var isGridView by remember { mutableStateOf(false) }
    var sortMode by remember { mutableStateOf(SortMode.TITLE_AZ) }
    var searchQuery by remember { mutableStateOf("") }
    var isSettingsOpen by remember { mutableStateOf(false) }

    // Playback & Queue State
    var activeQueue by remember { mutableStateOf(ActiveQueue.QUEUE_A) }
    var queueA by remember { mutableStateOf<List<Song>>(emptyList()) }
    var queueB by remember { mutableStateOf<List<Song>>(emptyList()) }
    var currentSong by remember { mutableStateOf<Song?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playbackPositionMs by remember { mutableStateOf(0L) }
    var isShuffle by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableStateOf(0) } // 0 = off, 1 = all, 2 = one
    var isNowPlayingOpen by remember { mutableStateOf(false) }
    var showLyricsView by remember { mutableStateOf(false) }

    // Observe DB / repository
    val allSongs by repository.visibleSongs.collectAsState(initial = emptyList())
    val hiddenSongs by repository.hiddenSongs.collectAsState(initial = emptyList())
    val mostPlayedSongs by repository.mostPlayedSongs.collectAsState(initial = emptyList())
    val playlists by repository.playlists.collectAsState(initial = emptyList())

    // Permission handling
    val permissionToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, permissionToRequest) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasAudioPermission = granted
        if (granted) {
            scope.launch { repository.scanLocalMedia() }
        }
    }

    LaunchedEffect(Unit) {
        if (!hasAudioPermission) {
            permissionLauncher.launch(permissionToRequest)
        } else {
            repository.scanLocalMedia()
        }
    }

    val currentQueue = if (activeQueue == ActiveQueue.QUEUE_A) queueA else queueB

    NeonWaveTheme(accentColor = selectedAccent) {
        Scaffold(
            containerColor = PureBlack,
            topBar = {
                Column(modifier = Modifier.fillMaxWidth().background(PureBlack)) {
                    // Top App Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .border(1.5.dp, selectedAccent.color, CircleShape)
                                    .background(DarkSurface),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "NeonWave",
                                    tint = selectedAccent.color,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "NeonWave",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Queue A/B Toggle badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .border(1.dp, selectedAccent.color.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                                    .background(DarkSurfaceElevated)
                                    .clickable {
                                        activeQueue = if (activeQueue == ActiveQueue.QUEUE_A) ActiveQueue.QUEUE_B else ActiveQueue.QUEUE_A
                                    }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = if (activeQueue == ActiveQueue.QUEUE_A) "QUEUE A" else "QUEUE B",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = selectedAccent.color
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(onClick = { isGridView = !isGridView }) {
                                Icon(
                                    imageVector = if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                                    contentDescription = "Toggle Grid/List",
                                    tint = TextSecondary
                                )
                            }
                            IconButton(onClick = { isSettingsOpen = true }) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Settings",
                                    tint = TextSecondary
                                )
                            }
                        }
                    }

                    // 5 Sections Compact Tab Row (Order: All Songs, Folders, Playlists, Hidden Albums, Most Played)
                    ScrollableTabRow(
                        selectedTabIndex = currentTab.ordinal,
                        containerColor = PureBlack,
                        contentColor = selectedAccent.color,
                        edgePadding = 16.dp,
                        divider = {},
                        indicator = {}
                    ) {
                        MainTab.values().forEach { tab ->
                            val isSelected = currentTab == tab
                            Box(
                                modifier = Modifier
                                    .padding(end = 8.dp, bottom = 8.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isSelected) selectedAccent.color.copy(alpha = 0.18f) else DarkSurface)
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) selectedAccent.color else Color.Transparent,
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .clickable { currentTab = tab }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = tab.title,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) selectedAccent.color else TextSecondary
                                )
                            }
                        }
                    }
                }
            },
            bottomBar = {
                // Mini Player when song is selected
                currentSong?.let { song ->
                    Column(modifier = Modifier.navigationBarsPadding()) {
                        MiniPlayer(
                            song = song,
                            isPlaying = isPlaying,
                            accentColor = selectedAccent.color,
                            onPlayPause = { isPlaying = !isPlaying },
                            onNext = {
                                if (currentQueue.isNotEmpty()) {
                                    val idx = currentQueue.indexOf(currentSong)
                                    val nextIdx = (idx + 1) % currentQueue.size
                                    currentSong = currentQueue[nextIdx]
                                }
                            },
                            onClick = { isNowPlayingOpen = true }
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(PureBlack)
            ) {
                when (currentTab) {
                    MainTab.ALL_SONGS -> {
                        AllSongsView(
                            songs = allSongs,
                            isGridView = isGridView,
                            accentColor = selectedAccent.color,
                            onSongClick = { song ->
                                currentSong = song
                                isPlaying = true
                                if (activeQueue == ActiveQueue.QUEUE_A && !queueA.contains(song)) {
                                    queueA = listOf(song) + queueA
                                } else if (activeQueue == ActiveQueue.QUEUE_B && !queueB.contains(song)) {
                                    queueB = listOf(song) + queueB
                                }
                                scope.launch { repository.recordMeaningfulPlay(song.id) }
                            },
                            onHideSong = { song ->
                                scope.launch { repository.setSongHidden(song.id, true) }
                            },
                            onAddToQueue = { song, q ->
                                if (q == ActiveQueue.QUEUE_A) queueA = queueA + song else queueB = queueB + song
                            }
                        )
                    }
                    MainTab.FOLDERS -> {
                        FoldersView(
                            songs = allSongs,
                            accentColor = selectedAccent.color,
                            onPlayFolder = { folderSongs ->
                                if (folderSongs.isNotEmpty()) {
                                    if (activeQueue == ActiveQueue.QUEUE_A) queueA = folderSongs else queueB = folderSongs
                                    currentSong = folderSongs.first()
                                    isPlaying = true
                                }
                            }
                        )
                    }
                    MainTab.PLAYLISTS -> {
                        PlaylistsView(
                            playlists = playlists,
                            accentColor = selectedAccent.color,
                            onCreatePlaylist = { name -> scope.launch { repository.createPlaylist(name) } },
                            onDeletePlaylist = { id -> scope.launch { repository.deletePlaylist(id) } }
                        )
                    }
                    MainTab.HIDDEN_ALBUMS -> {
                        HiddenAlbumsView(
                            hiddenSongs = hiddenSongs,
                            accentColor = selectedAccent.color,
                            onRestoreSong = { song ->
                                scope.launch { repository.setSongHidden(song.id, false) }
                            }
                        )
                    }
                    MainTab.MOST_PLAYED -> {
                        MostPlayedView(
                            songs = mostPlayedSongs,
                            accentColor = selectedAccent.color,
                            onSongClick = { song ->
                                currentSong = song
                                isPlaying = true
                            }
                        )
                    }
                    MainTab.NOT_PLAYED -> {
                        NotPlayedView(
                            songs = allSongs,
                            accentColor = selectedAccent.color,
                            onSongClick = { song ->
                                currentSong = song
                                isPlaying = true
                            }
                        )
                    }
                }
            }
        }

        // Now Playing Full Screen Modal
        if (isNowPlayingOpen && currentSong != null) {
            NowPlayingScreenModal(
                song = currentSong!!,
                isPlaying = isPlaying,
                accentColor = selectedAccent.color,
                activeQueue = activeQueue,
                isShuffle = isShuffle,
                repeatMode = repeatMode,
                showLyrics = showLyricsView,
                onDismiss = { isNowPlayingOpen = false },
                onPlayPause = { isPlaying = !isPlaying },
                onNext = {
                    if (currentQueue.isNotEmpty()) {
                        val idx = currentQueue.indexOf(currentSong)
                        val nextIdx = (idx + 1) % currentQueue.size
                        currentSong = currentQueue[nextIdx]
                    }
                },
                onPrevious = {
                    if (currentQueue.isNotEmpty()) {
                        val idx = currentQueue.indexOf(currentSong)
                        val prevIdx = if (idx > 0) idx - 1 else currentQueue.size - 1
                        currentSong = currentQueue[prevIdx]
                    }
                },
                onToggleShuffle = { isShuffle = !isShuffle },
                onToggleRepeat = { repeatMode = (repeatMode + 1) % 3 },
                onToggleLyrics = { showLyricsView = !showLyricsView },
                onSwitchQueue = {
                    activeQueue = if (activeQueue == ActiveQueue.QUEUE_A) ActiveQueue.QUEUE_B else ActiveQueue.QUEUE_A
                }
            )
        }

        // Settings Modal
        if (isSettingsOpen) {
            SettingsModal(
                accent = selectedAccent,
                onSelectAccent = { selectedAccent = it },
                onClearHistory = { scope.launch { repository.clearHistory() } },
                onRescan = { scope.launch { repository.scanLocalMedia() } },
                onDismiss = { isSettingsOpen = false }
            )
        }
    }
}

// Subcomponents for List/Grid and Sections
@Composable
fun AllSongsView(
    songs: List<Song>,
    isGridView: Boolean,
    accentColor: Color,
    onSongClick: (Song) -> Unit,
    onHideSong: (Song) -> Unit,
    onAddToQueue: (Song, ActiveQueue) -> Unit
) {
    if (songs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.MusicOff, contentDescription = null, tint = TextDisabled, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("No offline songs found", color = TextSecondary, fontSize = 15.sp)
                Text("Add audio files to your device storage", color = TextDisabled, fontSize = 12.sp)
            }
        }
    } else if (isGridView) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(songs) { song ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurface)
                        .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                        .clickable { onSongClick(song) }
                        .padding(12.dp)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkSurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.MusicNote, contentDescription = null, tint = accentColor.copy(alpha = 0.7f), modifier = Modifier.size(36.dp))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = TextPrimary)
                        Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = TextSecondary)
                    }
                }
            }
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(songs) { song ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurface)
                        .clickable { onSongClick(song) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurfaceElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, fontSize = 14.sp, color = TextPrimary)
                        Text("${song.artist} • ${song.formattedDuration()}", maxLines = 1, fontSize = 12.sp, color = TextSecondary)
                    }
                    IconButton(onClick = { onHideSong(song) }) {
                        Icon(Icons.Default.VisibilityOff, contentDescription = "Hide", tint = TextDisabled, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun FoldersView(songs: List<Song>, accentColor: Color, onPlayFolder: (List<Song>) -> Unit) {
    val folders = songs.groupBy { it.folderName }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(folders.keys.toList()) { folderName ->
            val folderSongs = folders[folderName] ?: emptyList()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkSurface)
                    .clickable { onPlayFolder(folderSongs) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Folder, contentDescription = null, tint = accentColor, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(folderName, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = TextPrimary)
                    Text("${folderSongs.size} songs", fontSize = 12.sp, color = TextSecondary)
                }
                Icon(Icons.Default.PlayArrow, contentDescription = "Play folder", tint = accentColor)
            }
        }
    }
}

@Composable
fun PlaylistsView(
    playlists: List<Playlist>,
    accentColor: Color,
    onCreatePlaylist: (String) -> Unit,
    onDeletePlaylist: (Long) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Button(
            onClick = { showDialog = true },
            colors = ButtonDefaults.buttonColors(containerColor = accentColor),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Add, contentDescription = null, tint = PureBlack)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Create New Playlist", color = PureBlack, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (playlists.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No playlists yet", color = TextSecondary)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(playlists) { pl ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(DarkSurface)
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.QueueMusic, contentDescription = null, tint = accentColor)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(pl.name, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium, color = TextPrimary)
                        IconButton(onClick = { onDeletePlaylist(pl.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TextDisabled)
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("New Playlist", color = TextPrimary) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    placeholder = { Text("Playlist name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newName.isNotBlank()) {
                        onCreatePlaylist(newName.trim())
                        newName = ""
                        showDialog = false
                    }
                }) {
                    Text("Create", color = accentColor)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Cancel", color = TextSecondary) }
            },
            containerColor = DarkSurfaceElevated
        )
    }
}

@Composable
fun HiddenAlbumsView(hiddenSongs: List<Song>, accentColor: Color, onRestoreSong: (Song) -> Unit) {
    if (hiddenSongs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No hidden songs", color = TextSecondary)
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(hiddenSongs) { song ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurface)
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(song.title, fontWeight = FontWeight.Medium, color = TextPrimary)
                        Text(song.artist, fontSize = 12.sp, color = TextSecondary)
                    }
                    Button(
                        onClick = { onRestoreSong(song) },
                        colors = ButtonDefaults.buttonColors(containerColor = accentColor.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Restore", color = accentColor, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun MostPlayedView(songs: List<Song>, accentColor: Color, onSongClick: (Song) -> Unit) {
    if (songs.isEmpty() || songs.none { it.playCount > 0 }) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Listening history will automatically appear here", color = TextSecondary)
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(songs.filter { it.playCount > 0 }) { song ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurface)
                        .clickable { onSongClick(song) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(accentColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${song.playCount}", color = accentColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(song.title, fontWeight = FontWeight.Medium, color = TextPrimary)
                        Text("${song.artist} • ${song.playCount} plays", fontSize = 12.sp, color = TextSecondary)
                    }
                }
            }
        }
    }
}

@Composable
fun NotPlayedView(songs: List<Song>, accentColor: Color, onSongClick: (Song) -> Unit) {
    val notPlayedSongs = songs.filter { !it.isHidden && (it.playCount == 0 || it.lastPlayed < System.currentTimeMillis() - 7 * 86400000L) }
        .sortedBy { it.lastPlayed }

    if (notPlayedSongs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("All songs have been listened to recently!", color = TextSecondary)
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurfaceElevated)
                        .padding(14.dp)
                ) {
                    Column {
                        Text(
                            text = "Rediscover Forgotten Music",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "${notPlayedSongs.size} tracks haven't been played in a long time or are unplayed",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
            items(notPlayedSongs) { song ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurface)
                        .clickable { onSongClick(song) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurfaceElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.History, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(song.title, fontWeight = FontWeight.Medium, color = TextPrimary)
                        val status = if (song.playCount == 0 || song.lastPlayed == 0L) "Never played" else "Not played in a long time"
                        Text("${song.artist} • $status", fontSize = 12.sp, color = TextSecondary)
                    }
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = accentColor)
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(
    song: Song,
    isPlaying: Boolean,
    accentColor: Color,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceElevated)
            .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.GraphicEq, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = TextPrimary)
                Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = TextSecondary)
            }
            IconButton(onClick = onPlayPause) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = "Play/Pause", tint = accentColor)
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = TextPrimary)
            }
        }
    }
}

@Composable
fun NowPlayingScreenModal(
    song: Song,
    isPlaying: Boolean,
    accentColor: Color,
    activeQueue: ActiveQueue,
    isShuffle: Boolean,
    repeatMode: Int,
    showLyrics: Boolean,
    onDismiss: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onToggleLyrics: () -> Unit,
    onSwitchQueue: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition()
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .systemBarsPadding()
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Close", tint = TextPrimary, modifier = Modifier.size(32.dp))
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, accentColor, RoundedCornerShape(16.dp))
                        .background(DarkSurfaceElevated)
                        .clickable { onSwitchQueue() }
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (activeQueue == ActiveQueue.QUEUE_A) "PLAYING: QUEUE A" else "PLAYING: QUEUE B",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = accentColor
                    )
                }
                IconButton(onClick = onToggleLyrics) {
                    Icon(
                        Icons.Default.Lyrics,
                        contentDescription = "Lyrics",
                        tint = if (showLyrics) accentColor else TextSecondary
                    )
                }
            }

            // Animated Artwork with Neon Pulsing Ring
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .scale(if (isPlaying) pulseScale else 1f),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(28.dp))
                        .border(
                            width = 2.dp,
                            brush = Brush.radialGradient(
                                colors = listOf(accentColor.copy(alpha = 0.8f), Color.Transparent)
                            ),
                            shape = RoundedCornerShape(28.dp)
                        )
                )
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(DarkSurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(90.dp)
                    )
                }
            }

            // Title & Artist
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(song.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary, textAlign = TextAlign.Center)
                Spacer(modifier = Modifier.height(4.dp))
                Text(song.artist, fontSize = 14.sp, color = TextSecondary, textAlign = TextAlign.Center)
            }

            // Animated Audio Waveform Equalizer
            Row(
                modifier = Modifier.fillMaxWidth().height(40.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(16) { index ->
                    val barHeight by infiniteTransition.animateFloat(
                        initialValue = 6f,
                        targetValue = (15 + (index * 7) % 25).toFloat(),
                        animationSpec = infiniteRepeatable(
                            animation = tween(350 + (index * 40), easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse
                        )
                    )
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height((if (isPlaying) barHeight else 4f).dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(accentColor)
                    )
                }
            }

            // Seekbar
            Column(modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = 0.35f,
                    onValueChange = {},
                    colors = SliderDefaults.colors(
                        thumbColor = accentColor,
                        activeTrackColor = accentColor,
                        inactiveTrackColor = DarkBorder
                    )
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("0:45", fontSize = 11.sp, color = TextSecondary)
                    Text(song.formattedDuration(), fontSize = 11.sp, color = TextSecondary)
                }
            }

            // Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onToggleShuffle) {
                    Icon(Icons.Default.Shuffle, contentDescription = "Shuffle", tint = if (isShuffle) accentColor else TextSecondary)
                }
                IconButton(onClick = onPrevious) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = TextPrimary, modifier = Modifier.size(32.dp))
                }
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(accentColor)
                        .clickable { onPlayPause() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = PureBlack,
                        modifier = Modifier.size(36.dp)
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = TextPrimary, modifier = Modifier.size(32.dp))
                }
                IconButton(onClick = onToggleRepeat) {
                    Icon(
                        imageVector = if (repeatMode == 2) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        contentDescription = "Repeat",
                        tint = if (repeatMode > 0) accentColor else TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsModal(
    accent: NeonAccent,
    onSelectAccent: (NeonAccent) -> Unit,
    onClearHistory: () -> Unit,
    onRescan: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("NeonWave Settings", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Accent Neon Color", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NeonAccent.values().forEach { item ->
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(item.color)
                                .border(
                                    width = if (accent == item) 2.5.dp else 0.dp,
                                    color = if (accent == item) Color.White else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { onSelectAccent(item) }
                        )
                    }
                }
                Divider(color = DarkBorder)
                Button(
                    onClick = { onRescan(); onDismiss() },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Rescan Music Library", color = TextPrimary)
                }
                Button(
                    onClick = { onClearHistory(); onDismiss() },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Clear Listening History", color = Color(0xFFFF5555))
                }
                Text("Version 1.0.0 • Pure Black & Neon", fontSize = 11.sp, color = TextSecondary)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done", color = accent.color) }
        },
        containerColor = DarkSurface
    )
}
