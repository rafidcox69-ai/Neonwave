package com.example.repository

import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import com.example.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ScanResult(
    val newSongsDiscovered: Int,
    val albumsCategorized: Int,
    val totalSongs: Int,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Automated scanner that monitors device storage via Android ContentObserver,
 * automatically detects newly downloaded or copied audio files, and
 * intelligently categorizes them into virtual folders based on album metadata.
 */
class AutoMediaScanner(
    private val context: Context,
    private val repository: MusicRepository,
    private val scope: CoroutineScope
) {
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _latestScanResult = MutableStateFlow<ScanResult?>(null)
    val latestScanResult: StateFlow<ScanResult?> = _latestScanResult.asStateFlow()

    private var contentObserver: ContentObserver? = null

    /**
     * Registers a MediaStore ContentObserver to automatically trigger
     * scanning and album-based folder categorization whenever new media is added.
     */
    fun startObservingStorage() {
        if (contentObserver != null) return

        val handler = Handler(Looper.getMainLooper())
        contentObserver = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)
                // Debounce or launch automated scan
                scope.launch {
                    scanAndCategorizeByAlbum()
                }
            }
        }

        context.contentResolver.registerContentObserver(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            true,
            contentObserver!!
        )
    }

    fun stopObservingStorage() {
        contentObserver?.let {
            try {
                context.contentResolver.unregisterContentObserver(it)
            } catch (_: Exception) {}
            contentObserver = null
        }
    }

    /**
     * Scans device storage via MediaStore and intelligently categorizes
     * each audio track into folders derived from Album and Artist metadata.
     */
    suspend fun scanAndCategorizeByAlbum(): ScanResult = withContext(Dispatchers.IO) {
        _isScanning.value = true

        val songsList = mutableListOf<Song>()
        val categorizedAlbums = mutableSetOf<String>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 10000"
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol)?.trim() ?: "Unknown Track"
                    val artist = cursor.getString(artistCol)?.trim() ?: "Unknown Artist"
                    val rawAlbum = cursor.getString(albumCol)?.trim() ?: ""
                    val durationMs = cursor.getLong(durationCol)
                    val albumId = cursor.getLong(albumIdCol)
                    val dataPath = cursor.getString(dataCol) ?: ""
                    val dateAdded = cursor.getLong(dateAddedCol)

                    val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    val albumArtUri = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"),
                        albumId
                    )

                    // Intelligent Album Folder Categorization:
                    // 1. If valid album name exists, create clean virtual album folder.
                    // 2. If artist is known and album exists, categorize under "[Album] Artist - Album" or "[Album] Album".
                    // 3. Fallback to physical parent directory if album tag is generic or missing.
                    val isGenericAlbum = rawAlbum.isEmpty() ||
                            rawAlbum.equals("<unknown>", ignoreCase = true) ||
                            rawAlbum.equals("Music", ignoreCase = true)

                    val file = File(dataPath)
                    val physicalParent = file.parentFile?.name ?: "Device Storage"

                    val intelligentFolderName = if (!isGenericAlbum) {
                        categorizedAlbums.add(rawAlbum)
                        if (artist.isNotEmpty() && !artist.equals("<unknown>", ignoreCase = true)) {
                            "$artist — $rawAlbum"
                        } else {
                            rawAlbum
                        }
                    } else {
                        physicalParent
                    }

                    val intelligentFolderPath = if (!isGenericAlbum) {
                        "/Albums/$intelligentFolderName"
                    } else {
                        file.parent ?: "/storage/emulated/0/Music"
                    }

                    val song = Song(
                        id = id,
                        title = title,
                        artist = artist,
                        album = if (!isGenericAlbum) rawAlbum else "Single / Unknown Album",
                        durationMs = durationMs,
                        contentUriString = contentUri.toString(),
                        albumArtUriString = albumArtUri.toString(),
                        folderPath = intelligentFolderPath,
                        folderName = intelligentFolderName,
                        dateAdded = dateAdded,
                        playCount = 0,
                        isHidden = false,
                        isFavorite = false,
                        lrcContent = null
                    )
                    songsList.add(song)
                }
            }

            if (songsList.isNotEmpty()) {
                repository.insertDiscoveredSongs(songsList)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            _isScanning.value = false
        }

        val result = ScanResult(
            newSongsDiscovered = songsList.size,
            albumsCategorized = categorizedAlbums.size,
            totalSongs = songsList.size
        )
        _latestScanResult.value = result
        result
    }
}
