package com.example.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.example.data.NeonWaveDatabase
import com.example.model.ActiveQueue
import com.example.model.Playlist
import com.example.model.PlaylistSongCrossRef
import com.example.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class MusicRepository(private val context: Context) {
    private val database = NeonWaveDatabase.getDatabase(context)
    private val songDao = database.songDao()
    private val playlistDao = database.playlistDao()

    val visibleSongs: Flow<List<Song>> = songDao.getAllVisibleSongs()
    val hiddenSongs: Flow<List<Song>> = songDao.getHiddenSongs()
    val mostPlayedSongs: Flow<List<Song>> = songDao.getMostPlayedSongs()
    val playlists: Flow<List<Playlist>> = playlistDao.getAllPlaylists()

    /**
     * Discovers audio files on the local device using MediaStore.
     * Extracts title, artist, album, duration, folder hierarchy, and album artwork.
     */
    suspend fun scanLocalMedia(): List<Song> = withContext(Dispatchers.IO) {
        val songsList = mutableListOf<Song>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 15000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown Track"
                val artist = cursor.getString(artistCol) ?: "Unknown Artist"
                val album = cursor.getString(albumCol) ?: "Unknown Album"
                val durationMs = cursor.getLong(durationCol)
                val albumId = cursor.getLong(albumIdCol)
                val dataPath = cursor.getString(dataCol) ?: ""
                val dateAdded = cursor.getLong(dateAddedCol)

                val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                val albumArtUri = ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"),
                    albumId
                )

                val file = File(dataPath)
                val folderPath = file.parent ?: "/storage/emulated/0/Music"
                val folderName = file.parentFile?.name ?: "Music"

                // Check if song already exists in local database to preserve user states
                val existing = songDao.getSongById(id)
                val song = Song(
                    id = id,
                    title = title,
                    artist = artist,
                    album = album,
                    durationMs = durationMs,
                    contentUriString = contentUri.toString(),
                    albumArtUriString = albumArtUri.toString(),
                    folderPath = folderPath,
                    folderName = folderName,
                    dateAdded = dateAdded,
                    playCount = existing?.playCount ?: 0,
                    isHidden = existing?.isHidden ?: false,
                    isFavorite = existing?.isFavorite ?: false,
                    lrcContent = existing?.lrcContent
                )
                songsList.add(song)
            }
        }

        if (songsList.isNotEmpty()) {
            songDao.insertOrUpdateSongs(songsList)
        }
        songsList
    }

    suspend fun insertDiscoveredSongs(newSongs: List<Song>) = withContext(Dispatchers.IO) {
        val merged = newSongs.map { song ->
            val existing = songDao.getSongById(song.id)
            if (existing != null) {
                song.copy(
                    playCount = existing.playCount,
                    isHidden = existing.isHidden,
                    isFavorite = existing.isFavorite,
                    lrcContent = existing.lrcContent ?: song.lrcContent
                )
            } else {
                song
            }
        }
        songDao.insertOrUpdateSongs(merged)
    }

    suspend fun setSongHidden(songId: Long, hidden: Boolean) {
        songDao.setHidden(songId, hidden)
    }

    suspend fun toggleFavorite(songId: Long, isFav: Boolean) {
        songDao.setFavorite(songId, isFav)
    }

    suspend fun recordMeaningfulPlay(songId: Long) {
        songDao.incrementPlayCount(songId)
    }

    suspend fun clearHistory() {
        songDao.clearListeningHistory()
    }

    suspend fun updateLyrics(songId: Long, lrcContent: String) {
        songDao.updateLyrics(songId, lrcContent)
    }

    suspend fun createPlaylist(name: String): Long {
        return playlistDao.insertPlaylist(Playlist(name = name))
    }

    suspend fun renamePlaylist(playlistId: Long, newName: String) {
        playlistDao.renamePlaylist(playlistId, newName)
    }

    suspend fun deletePlaylist(playlistId: Long) {
        playlistDao.deletePlaylist(playlistId)
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long, orderIndex: Int) {
        playlistDao.addSongToPlaylist(PlaylistSongCrossRef(playlistId, songId, orderIndex))
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        playlistDao.removeSongFromPlaylist(playlistId, songId)
    }

    fun getSongsForPlaylist(playlistId: Long): Flow<List<Song>> {
        return playlistDao.getSongsForPlaylist(playlistId)
    }
}
