package com.example.model

import android.net.Uri
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Core Song representation for NeonWave.
 * Supports both MediaStore local audio metadata and persistent user states
 * such as play count, hidden status, favorites, and synchronized lyrics.
 */
@Entity(tableName = "songs")
data class Song(
    @PrimaryKey
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val contentUriString: String,
    val albumArtUriString: String? = null,
    val folderPath: String = "",
    val folderName: String = "",
    val dateAdded: Long = 0L,
    val playCount: Int = 0,
    val lastPlayed: Long = 0L,
    val isHidden: Boolean = false,
    val isFavorite: Boolean = false,
    val lrcContent: String? = null
) {
    val contentUri: Uri
        get() = Uri.parse(contentUriString)

    val albumArtUri: Uri?
        get() = albumArtUriString?.let { Uri.parse(it) }

    fun formattedDuration(): String {
        val totalSecs = durationMs / 1000
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        return String.format("%d:%02d", mins, secs)
    }
}
