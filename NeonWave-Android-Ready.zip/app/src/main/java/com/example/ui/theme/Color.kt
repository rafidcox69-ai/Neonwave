package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure Black Background
val PureBlack = Color(0xFF000000)
val DarkSurface = Color(0xFF0D0D11)
val DarkSurfaceElevated = Color(0xFF14141A)
val DarkBorder = Color(0xFF1F1F28)

// Neon Accent Palette Options
val NeonCyan = Color(0xFF00F0FF)
val ElectricBlue = Color(0xFF0066FF)
val NeonViolet = Color(0xFFB026FF)
val NeonGreen = Color(0xFF00FF88)

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF8E8E9F)
val TextDisabled = Color(0xFF4A4A5A)

enum class NeonAccent(val displayName: String, val color: Color) {
    CYAN("Neon Cyan", NeonCyan),
    BLUE("Electric Blue", ElectricBlue),
    VIOLET("Neon Violet", NeonViolet),
    GREEN("Neon Green", NeonGreen)
}
