import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  Heart,
  Search,
  Settings,
  Folder as FolderIcon,
  ListMusic,
  EyeOff,
  Eye,
  TrendingUp,
  LayoutList,
  LayoutGrid,
  ChevronDown,
  Volume2,
  Sliders,
  Plus,
  Trash2,
  Edit2,
  FileText,
  Clock,
  RotateCcw,
  Upload,
  Check,
  Disc,
  Smartphone,
  FolderSync,
  Sparkles,
  History,
  Download,
  X
} from 'lucide-react';
import { Song, Playlist, MainTab, SortOption, ViewMode, ActiveQueueId, RepeatMode, NeonTheme } from './types';
import { INITIAL_SONGS, INITIAL_PLAYLISTS } from './initialData';
import { generateSynthAudio } from './audioGenerator';
import {
  cleanAlbumMetadata,
  getIntelligentAlbumFolder,
  categorizeSongsByAlbumMetadata,
  scanDeviceMusicDirectory
} from './scanner';
import { DownloadModal } from './DownloadModal';

const THEMES: NeonTheme[] = [
  { id: 'cyan', name: 'Neon Cyan', color: '#00F0FF', glowRgba: 'rgba(0, 240, 255, 0.4)' },
  { id: 'blue', name: 'Electric Blue', color: '#0066FF', glowRgba: 'rgba(0, 102, 255, 0.4)' },
  { id: 'violet', name: 'Neon Violet', color: '#B026FF', glowRgba: 'rgba(176, 38, 255, 0.4)' },
  { id: 'green', name: 'Neon Green', color: '#00FF88', glowRgba: 'rgba(0, 255, 136, 0.4)' },
];

export default function App() {
  // Theme state
  const [currentTheme, setCurrentTheme] = useState<NeonTheme>(() => {
    const saved = localStorage.getItem('neonwave_theme');
    return THEMES.find((t) => t.id === saved) || THEMES[0];
  });

  // Songs & Playlists state
  const [songs, setSongs] = useState<Song[]>(() => {
    const saved = localStorage.getItem('neonwave_songs');
    if (saved) {
      try {
        const parsed: Song[] = JSON.parse(saved);
        // Stale blob URLs from previous page loads/sessions are DEAD. Clean them so fresh offline audio is generated!
        return parsed.map((s) => {
          if (s.id.startsWith('track-') && s.url && s.url.startsWith('blob:')) {
            return { ...s, url: '' };
          }
          return s;
        });
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_SONGS;
  });

  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    const saved = localStorage.getItem('neonwave_playlists');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_PLAYLISTS;
  });

  // Navigation & View state
  const [currentTab, setCurrentTab] = useState<MainTab>('all');
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    return (localStorage.getItem('neonwave_viewmode') as ViewMode) || 'list';
  });
  const [sortOption, setSortOption] = useState<SortOption>('title-asc');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFolder, setSelectedFolder] = useState<string | null>(null);
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);

  // Filters for "Not played for long time" inside Folders and Playlists
  const [folderSubFilter, setFolderSubFilter] = useState<'all' | 'not-played'>('all');
  const [playlistSubFilter, setPlaylistSubFilter] = useState<'all' | 'not-played'>('all');

  // Dual Play Queues
  const [activeQueueId, setActiveQueueId] = useState<ActiveQueueId>(() => {
    return (localStorage.getItem('neonwave_activequeue') as ActiveQueueId) || 'A';
  });
  const [queueA, setQueueA] = useState<string[]>(() => {
    const saved = localStorage.getItem('neonwave_queue_a');
    return saved ? JSON.parse(saved) : ['track-1', 'track-2', 'track-3', 'track-4', 'track-5', 'track-6'];
  });
  const [queueB, setQueueB] = useState<string[]>(() => {
    const saved = localStorage.getItem('neonwave_queue_b');
    return saved ? JSON.parse(saved) : ['track-3', 'track-4'];
  });

  // Current Playback state
  const [currentSongId, setCurrentSongId] = useState<string | null>(() => {
    return localStorage.getItem('neonwave_current_song') || 'track-1';
  });
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(65);
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('all');
  const [volume, setVolume] = useState(0.85);

  // Modals & Panels
  const [isNowPlayingOpen, setIsNowPlayingOpen] = useState(false);
  const [isLyricsMode, setIsLyricsMode] = useState(false);
  const [isEqualizerOpen, setIsEqualizerOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isQueueDrawerOpen, setIsQueueDrawerOpen] = useState(false);
  const [isLyricsEditorOpen, setIsLyricsEditorOpen] = useState(false);
  const [editedLyrics, setEditedLyrics] = useState('');
  const [showAndroidInfoModal, setShowAndroidInfoModal] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  // Equalizer values (dB: -12 to +12)
  const [eqGains, setEqGains] = useState<number[]>([0, 0, 0, 0, 0]);
  const [eqPreset, setEqPreset] = useState<string>('flat');

  // Automated Storage Scan state
  const [isScanning, setIsScanning] = useState(false);
  const [scanToast, setScanToast] = useState<{ message: string; sub?: string } | null>(null);
  const [autoScanEnabled, setAutoScanEnabled] = useState<boolean>(() => {
    return localStorage.getItem('neonwave_autoscan') !== 'false';
  });

  // Sleep timer
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);
  const [sleepTimerRemaining, setSleepTimerRemaining] = useState<number | null>(null);

  // Meaningful listening tracking: track time played on current song
  const playDurationRef = useRef(0);
  const hasIncrementedRef = useRef(false);

  // Audio Context & Nodes refs
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);
  const eqFiltersRef = useRef<BiquadFilterNode[]>([]);
  const visualizerCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const miniVisualizerCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Lyrics scrolling
  const lyricsContainerRef = useRef<HTMLDivElement | null>(null);
  const activeLyricRef = useRef<HTMLParagraphElement | null>(null);
  const [userIsScrollingLyrics, setUserIsScrollingLyrics] = useState(false);
  const userScrollTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize CSS theme variables
  useEffect(() => {
    document.documentElement.style.setProperty('--neon-current', currentTheme.color);
    document.documentElement.style.setProperty('--neon-glow', currentTheme.glowRgba);
    localStorage.setItem('neonwave_theme', currentTheme.id);
  }, [currentTheme]);

  // Persist songs, playlists, queues
  useEffect(() => {
    const toSave = songs.map((s) => {
      if (s.id.startsWith('track-') && s.url && s.url.startsWith('blob:')) {
        return { ...s, url: '' };
      }
      return s;
    });
    localStorage.setItem('neonwave_songs', JSON.stringify(toSave));
  }, [songs]);

  useEffect(() => {
    localStorage.setItem('neonwave_playlists', JSON.stringify(playlists));
  }, [playlists]);

  useEffect(() => {
    localStorage.setItem('neonwave_queue_a', JSON.stringify(queueA));
  }, [queueA]);

  useEffect(() => {
    localStorage.setItem('neonwave_queue_b', JSON.stringify(queueB));
  }, [queueB]);

  useEffect(() => {
    localStorage.setItem('neonwave_activequeue', activeQueueId);
  }, [activeQueueId]);

  useEffect(() => {
    if (currentSongId) {
      localStorage.setItem('neonwave_current_song', currentSongId);
    }
  }, [currentSongId]);

  useEffect(() => {
    localStorage.setItem('neonwave_viewmode', viewMode);
  }, [viewMode]);

  useEffect(() => {
    localStorage.setItem('neonwave_autoscan', String(autoScanEnabled));
  }, [autoScanEnabled]);

  // Automated scan trigger on app resume / focus
  useEffect(() => {
    if (!autoScanEnabled) return;

    const handleResume = () => {
      if (document.visibilityState === 'visible') {
        setSongs((prev) => {
          const { categorizedSongs } = categorizeSongsByAlbumMetadata(prev);
          return categorizedSongs;
        });
      }
    };

    document.addEventListener('visibilitychange', handleResume);
    window.addEventListener('focus', handleResume);
    return () => {
      document.removeEventListener('visibilitychange', handleResume);
      window.removeEventListener('focus', handleResume);
    };
  }, [autoScanEnabled]);

  // Helper to determine synth style for built-in tracks
  const getStyleForSong = (song: Song): 'neon-drive' | 'midnight-runner' | 'cyber-drift' | 'retro-dream' => {
    const styles: Array<'neon-drive' | 'midnight-runner' | 'cyber-drift' | 'retro-dream'> = [
      'neon-drive',
      'cyber-drift',
      'midnight-runner',
      'retro-dream'
    ];
    const idx = INITIAL_SONGS.findIndex((s) => s.id === song.id);
    return idx >= 0 ? styles[idx % styles.length] : 'neon-drive';
  };

  // Ensure song has a valid, playable audio URL in memory
  const ensureSongAudio = async (song: Song): Promise<string> => {
    if (song.url && song.url.length > 5 && !song.url.startsWith('blob:null')) {
      return song.url;
    }
    const style = getStyleForSong(song);
    const blobUrl = await generateSynthAudio(style, 32, song.id);
    setSongs((prev) =>
      prev.map((s) => (s.id === song.id ? { ...s, url: blobUrl } : s))
    );
    return blobUrl;
  };

  // Web Audio Graph setup with 5-band EQ, Analyser, and Master Gain
  const setupAudioGraph = () => {
    if (audioContextRef.current) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      audioContextRef.current = ctx;

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      analyserRef.current = analyser;

      const freqs = [60, 250, 1000, 4000, 16000];
      const filters = freqs.map((f, idx) => {
        const filter = ctx.createBiquadFilter();
        filter.type = idx === 0 ? 'lowshelf' : idx === 4 ? 'highshelf' : 'peaking';
        filter.frequency.setValueAtTime(f, ctx.currentTime);
        filter.gain.setValueAtTime(eqGains[idx] || 0, ctx.currentTime);
        return filter;
      });
      eqFiltersRef.current = filters;

      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(volume, ctx.currentTime);
      masterGainRef.current = masterGain;

      if (audioRef.current && !sourceNodeRef.current) {
        const source = ctx.createMediaElementSource(audioRef.current);
        sourceNodeRef.current = source;

        let node: AudioNode = source;
        filters.forEach((filter) => {
          node.connect(filter);
          node = filter;
        });
        node.connect(analyser);
        analyser.connect(masterGain);
        masterGain.connect(ctx.destination);
      }
    } catch (err) {
      console.warn('Web Audio graph setup:', err);
    }
  };

  // Wakes up AudioContext immediately during a user gesture
  const wakeAudioContext = () => {
    try {
      if (!audioContextRef.current) {
        setupAudioGraph();
      }
      if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
        audioContextRef.current.resume();
      }
    } catch (err) {
      console.warn('AudioContext wake note:', err);
    }
  };

  // Pre-generate audio for built-in sample tracks on mount
  useEffect(() => {
    const initAudio = async () => {
      // Setup audio graph on first user interaction anywhere
      const onUserInteraction = () => {
        wakeAudioContext();
        window.removeEventListener('click', onUserInteraction);
        window.removeEventListener('touchstart', onUserInteraction);
      };
      window.addEventListener('click', onUserInteraction);
      window.addEventListener('touchstart', onUserInteraction);

      // Pre-generate current song first so it's ready immediately
      const initial = songs.find((s) => s.id === currentSongId) || songs[0];
      if (initial && !initial.url) {
        await ensureSongAudio(initial);
      }

      // Generate remaining sample tracks in background
      for (const song of songs) {
        if (song.id !== initial?.id && !song.url && song.id.startsWith('track-')) {
          ensureSongAudio(song).catch(() => {});
        }
      }
    };

    initAudio();
  }, []);

  // Sync EQ gains to Web Audio filters
  useEffect(() => {
    if (!audioContextRef.current) return;
    eqFiltersRef.current.forEach((filter, idx) => {
      if (filter) {
        filter.gain.setValueAtTime(eqGains[idx] || 0, audioContextRef.current!.currentTime);
      }
    });
  }, [eqGains]);

  // Current active queue song list
  const currentQueueSongIds = activeQueueId === 'A' ? queueA : queueB;
  const currentSong = useMemo(() => {
    return songs.find((s) => s.id === currentSongId) || songs[0] || null;
  }, [songs, currentSongId]);

  useEffect(() => {
    playDurationRef.current = 0;
    hasIncrementedRef.current = false;
  }, [currentSongId]);

  // Audio element time tracking and play count increment logic
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      if (audio.duration && !isNaN(audio.duration)) {
        setDuration(audio.duration);
      }

      if (isPlaying && !hasIncrementedRef.current && currentSongId) {
        playDurationRef.current += 0.25;
        if (playDurationRef.current >= 10) {
          hasIncrementedRef.current = true;
          setSongs((prev) =>
            prev.map((s) =>
              s.id === currentSongId
                ? { ...s, playCount: (s.playCount || 0) + 1, lastPlayed: Date.now() }
                : s
            )
          );
        }
      }
    };

    const onEnded = () => {
      handleNext();
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('ended', onEnded);
    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('ended', onEnded);
    };
  }, [isPlaying, currentSongId, currentQueueSongIds, isShuffle, repeatMode]);

  // Audio play/pause sync when state changes
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      if (currentSong) {
        ensureSongAudio(currentSong).then((url) => {
          if (audio.src !== url) {
            audio.src = url;
            audio.load();
          }
          if (audioContextRef.current?.state === 'suspended') {
            audioContextRef.current.resume();
          }
          audio.play().catch((err) => {
            console.warn('Playback play() note:', err);
          });
        });
      }
    } else {
      audio.pause();
    }
  }, [isPlaying, currentSongId]);

  // Sync volume to audio element and master gain
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
    if (masterGainRef.current && audioContextRef.current) {
      masterGainRef.current.gain.setValueAtTime(volume, audioContextRef.current.currentTime);
    }
  }, [volume]);

  // Sleep timer interval
  useEffect(() => {
    if (sleepTimerMinutes === null) {
      setSleepTimerRemaining(null);
      return;
    }
    setSleepTimerRemaining(sleepTimerMinutes * 60);

    const interval = setInterval(() => {
      setSleepTimerRemaining((prev) => {
        if (prev === null || prev <= 1) {
          setIsPlaying(false);
          setSleepTimerMinutes(null);
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepTimerMinutes]);

  // Live Waveform Equalizer Canvas Animation
  useEffect(() => {
    const renderVisualizer = () => {
      const analyser = analyserRef.current;
      const canvases = [visualizerCanvasRef.current, miniVisualizerCanvasRef.current];

      canvases.forEach((canvas) => {
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const barCount = canvas.width < 100 ? 12 : 28;
        const barWidth = canvas.width / barCount - 2;

        if (isPlaying && analyser) {
          const bufferLength = analyser.frequencyBinCount;
          const dataArray = new Uint8Array(bufferLength);
          analyser.getByteFrequencyData(dataArray);

          for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor((i / barCount) * (bufferLength / 2));
            const value = dataArray[dataIndex] || 0;
            const percent = value / 255;
            const barHeight = Math.max(3, percent * (canvas.height - 4));

            ctx.fillStyle = currentTheme.color;
            ctx.shadowColor = currentTheme.color;
            ctx.shadowBlur = 6;

            const x = i * (barWidth + 2);
            const y = canvas.height - barHeight;

            ctx.beginPath();
            ctx.roundRect(x, y, barWidth, barHeight, 2);
            ctx.fill();
          }
        } else {
          for (let i = 0; i < barCount; i++) {
            const x = i * (barWidth + 2);
            ctx.fillStyle = '#1e1e24';
            ctx.shadowBlur = 0;
            ctx.beginPath();
            ctx.roundRect(x, canvas.height - 3, barWidth, 3, 1);
            ctx.fill();
          }
        }
      });

      animationFrameRef.current = requestAnimationFrame(renderVisualizer);
    };

    animationFrameRef.current = requestAnimationFrame(renderVisualizer);
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, currentTheme]);

  // Parse LRC Lyrics
  const parsedLyrics = useMemo(() => {
    if (!currentSong?.lyrics) return [];
    const lines = currentSong.lyrics.split('\n');
    const result: { time: number; text: string }[] = [];
    const timeRegex = /\[(\d{2}):(\d{2})\.(\d{2,3})\]/;

    lines.forEach((line) => {
      const match = timeRegex.exec(line);
      if (match) {
        const minutes = parseInt(match[1], 10);
        const seconds = parseInt(match[2], 10);
        const fraction = parseFloat('0.' + match[3]);
        const time = minutes * 60 + seconds + fraction;
        const text = line.replace(timeRegex, '').trim();
        if (text) {
          result.push({ time, text });
        }
      }
    });
    return result.sort((a, b) => a.time - b.time);
  }, [currentSong?.lyrics]);

  // Active lyric index based on currentTime
  const activeLyricIndex = useMemo(() => {
    if (parsedLyrics.length === 0) return -1;
    for (let i = parsedLyrics.length - 1; i >= 0; i--) {
      if (currentTime >= parsedLyrics[i].time - 0.2) {
        return i;
      }
    }
    return 0;
  }, [parsedLyrics, currentTime]);

  // Current active lyric line string
  const currentLyricLine = useMemo(() => {
    if (!currentSong?.lyrics || parsedLyrics.length === 0) return null;
    if (activeLyricIndex >= 0 && activeLyricIndex < parsedLyrics.length) {
      return parsedLyrics[activeLyricIndex].text;
    }
    return parsedLyrics[0]?.text || null;
  }, [currentSong?.lyrics, parsedLyrics, activeLyricIndex]);

  // Auto-scroll lyrics smoothly to active line unless user manually scrolls
  useEffect(() => {
    if (!isLyricsMode || userIsScrollingLyrics || activeLyricIndex === -1) return;
    if (activeLyricRef.current && lyricsContainerRef.current) {
      activeLyricRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [activeLyricIndex, isLyricsMode, userIsScrollingLyrics]);

  const handleLyricsUserScroll = () => {
    setUserIsScrollingLyrics(true);
    if (userScrollTimeoutRef.current) clearTimeout(userScrollTimeoutRef.current);
    userScrollTimeoutRef.current = setTimeout(() => {
      setUserIsScrollingLyrics(false);
    }, 4500);
  };

  const syncLyricsToCurrent = () => {
    setUserIsScrollingLyrics(false);
    if (activeLyricRef.current) {
      activeLyricRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  };

  // Helper: check if a song has not been played for a long time (>7 days or never played)
  const isNotPlayedLongTime = (song: Song): boolean => {
    if (song.isHidden) return false;
    if (!song.playCount || song.playCount === 0 || !song.lastPlayed || song.lastPlayed === 0) {
      return true;
    }
    const sevenDaysAgo = Date.now() - 7 * 86400000;
    return song.lastPlayed < sevenDaysAgo;
  };

  // Helper: format last played time nicely
  const formatLastPlayed = (song: Song): string => {
    if (!song.playCount || song.playCount === 0 || !song.lastPlayed || song.lastPlayed === 0) {
      return 'Never played';
    }
    const diffMs = Date.now() - song.lastPlayed;
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffDays <= 0) {
      const diffHours = Math.floor(diffMs / 3600000);
      return diffHours <= 1 ? 'Played recently' : `Played ${diffHours}h ago`;
    }
    if (diffDays === 1) return 'Played yesterday';
    if (diffDays < 30) return `Not played in ${diffDays}d`;
    const diffMonths = Math.floor(diffDays / 30);
    return `Not played in ${diffMonths}mo`;
  };

  // Playback Navigation Handlers
  const handlePlaySong = async (song: Song) => {
    wakeAudioContext();
    setCurrentSongId(song.id);
    setIsPlaying(true);
    setSongs((prev) =>
      prev.map((s) => (s.id === song.id ? { ...s, lastPlayed: Date.now() } : s))
    );

    if (activeQueueId === 'A') {
      if (!queueA.includes(song.id)) {
        setQueueA([song.id, ...queueA]);
      }
    } else {
      if (!queueB.includes(song.id)) {
        setQueueB([song.id, ...queueB]);
      }
    }

    try {
      const url = await ensureSongAudio(song);
      const audio = audioRef.current;
      if (audio) {
        if (audio.src !== url) {
          audio.src = url;
          audio.load();
        }
        audio.play().catch((err) => {
          console.warn('Playback play() call:', err);
        });
      }
    } catch (e) {
      console.error('Audio preparation failed:', e);
    }
  };

  const handleTogglePlayPause = async () => {
    wakeAudioContext();
    if (isPlaying) {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      if (currentSong) {
        try {
          const url = await ensureSongAudio(currentSong);
          const audio = audioRef.current;
          if (audio) {
            if (!audio.src || audio.src !== url) {
              audio.src = url;
              audio.load();
            }
            audio.play().catch((err) => {
              console.warn('Play error:', err);
            });
          }
        } catch (e) {
          console.error('Play toggle failed:', e);
        }
      }
    }
  };

  const handleNext = () => {
    if (currentQueueSongIds.length === 0) return;
    if (repeatMode === 'one' && audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play();
      return;
    }

    if (isShuffle) {
      const nextIdx = Math.floor(Math.random() * currentQueueSongIds.length);
      setCurrentSongId(currentQueueSongIds[nextIdx]);
      setIsPlaying(true);
      return;
    }

    const currentIndex = currentQueueSongIds.indexOf(currentSongId || '');
    if (currentIndex === -1 || currentIndex === currentQueueSongIds.length - 1) {
      if (repeatMode === 'all') {
        setCurrentSongId(currentQueueSongIds[0]);
        setIsPlaying(true);
      } else {
        setIsPlaying(false);
      }
    } else {
      setCurrentSongId(currentQueueSongIds[currentIndex + 1]);
      setIsPlaying(true);
    }
  };

  const handlePrevious = () => {
    if (currentTime > 3 && audioRef.current) {
      audioRef.current.currentTime = 0;
      return;
    }
    if (currentQueueSongIds.length === 0) return;

    const currentIndex = currentQueueSongIds.indexOf(currentSongId || '');
    if (currentIndex <= 0) {
      setCurrentSongId(currentQueueSongIds[currentQueueSongIds.length - 1]);
    } else {
      setCurrentSongId(currentQueueSongIds[currentIndex - 1]);
    }
    setIsPlaying(true);
  };

  const handleSeek = (newTime: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const toggleFavorite = (songId: string) => {
    setSongs((prev) =>
      prev.map((s) => (s.id === songId ? { ...s, isFavorite: !s.isFavorite } : s))
    );
  };

  const hideSong = (songId: string) => {
    setSongs((prev) =>
      prev.map((s) => (s.id === songId ? { ...s, isHidden: true } : s))
    );
  };

  const restoreSong = (songId: string) => {
    setSongs((prev) =>
      prev.map((s) => (s.id === songId ? { ...s, isHidden: false } : s))
    );
  };

  const addToQueue = (songId: string, targetQueue: ActiveQueueId) => {
    if (targetQueue === 'A') {
      if (!queueA.includes(songId)) setQueueA([...queueA, songId]);
    } else {
      if (!queueB.includes(songId)) setQueueB([...queueB, songId]);
    }
  };

  const removeFromQueue = (songId: string, targetQueue: ActiveQueueId) => {
    if (targetQueue === 'A') {
      setQueueA(queueA.filter((id) => id !== songId));
    } else {
      setQueueB(queueB.filter((id) => id !== songId));
    }
  };

  const showToast = (message: string, sub?: string) => {
    setScanToast({ message, sub });
    setTimeout(() => {
      setScanToast(null);
    }, 4500);
  };

  const handleSmartCategorizeAll = () => {
    setIsScanning(true);
    setTimeout(() => {
      const { categorizedSongs, folderNames } = categorizeSongsByAlbumMetadata(songs);
      setSongs(categorizedSongs);
      setIsScanning(false);
      showToast(
        'Intelligent Categorization Complete',
        `${songs.length} tracks organized into ${folderNames.length} album folders.`
      );
    }, 400);
  };

  const handleScanDeviceStorage = async () => {
    try {
      setIsScanning(true);
      const { discoveredSongs, report } = await scanDeviceMusicDirectory();
      if (discoveredSongs.length > 0) {
        setSongs((prev) => {
          const existingKeys = new Set(prev.map((s) => `${s.title.toLowerCase()}||${s.artist.toLowerCase()}`));
          const fresh = discoveredSongs.filter((s) => !existingKeys.has(`${s.title.toLowerCase()}||${s.artist.toLowerCase()}`));
          return [...fresh, ...prev];
        });
        showToast('Storage Scan Succeeded', report.message);
      } else {
        showToast('Storage Scan Complete', 'No new audio files found in directory.');
      }
    } catch (err: any) {
      if (!err.message?.includes('cancelled') && !err.message?.includes('AbortError')) {
        handleSmartCategorizeAll();
      }
    } finally {
      setIsScanning(false);
    }
  };

  const handleLocalAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newDiscovered: Song[] = [];
    Array.from(files).forEach((file) => {
      const url = URL.createObjectURL(file);
      const cleanTitle = file.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' ');

      let artist = 'Local Artist';
      let title = cleanTitle;
      let rawAlbum = 'Device Storage';

      const parts = cleanTitle.split(' - ').map((p) => p.trim());
      if (parts.length >= 3) {
        artist = parts[1];
        title = parts.slice(2).join(' - ');
      } else if (parts.length === 2) {
        artist = parts[0];
        title = parts[1];
      }

      const bracketMatch = /\[(.*?)\]|\((.*?)\)/.exec(title);
      if (bracketMatch && bracketMatch[1]) {
        rawAlbum = bracketMatch[1];
      }

      const cleanAlbum = cleanAlbumMetadata(rawAlbum, title);
      const intelligentFolder = getIntelligentAlbumFolder({ artist, album: cleanAlbum, title });

      const newSong: Song = {
        id: 'local-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
        title: title,
        artist: artist,
        album: cleanAlbum,
        duration: 180,
        url: url,
        folder: intelligentFolder,
        dateAdded: Date.now(),
        playCount: 0,
        lastPlayed: 0,
        isHidden: false,
        isFavorite: false,
        artwork: 'linear-gradient(135deg, #111118 0%, #1a1a24 100%)',
        lyrics: `[00:00.00]${title}\n[00:04.00]${artist}\n[00:08.00]Album: ${cleanAlbum}`
      };
      newDiscovered.push(newSong);
    });

    setSongs((prev) => [...newDiscovered, ...prev]);
    if (activeQueueId === 'A') {
      setQueueA((prev) => [...newDiscovered.map((s) => s.id), ...prev]);
    } else {
      setQueueB((prev) => [...newDiscovered.map((s) => s.id), ...prev]);
    }

    const uniqueFolders = new Set(newDiscovered.map((s) => s.folder));
    showToast(
      'Automated Scan & Import Complete',
      `Detected ${newDiscovered.length} new audio files. Categorized into ${uniqueFolders.size} album folders.`
    );
  };

  // Filtered & Sorted Songs
  const visibleSongs = useMemo(() => {
    return songs.filter((s) => !s.isHidden);
  }, [songs]);

  const hiddenSongs = useMemo(() => {
    return songs.filter((s) => s.isHidden);
  }, [songs]);

  const mostPlayedSongs = useMemo(() => {
    return songs
      .filter((s) => !s.isHidden && (s.playCount || 0) > 0)
      .sort((a, b) => (b.playCount || 0) - (a.playCount || 0));
  }, [songs]);

  // Section 6: Not Played for Long Time
  const notPlayedSongs = useMemo(() => {
    return visibleSongs
      .filter((s) => isNotPlayedLongTime(s))
      .sort((a, b) => (a.lastPlayed || 0) - (b.lastPlayed || 0));
  }, [visibleSongs]);

  const displayedAllSongs = useMemo(() => {
    let list = visibleSongs.filter((s) => {
      const q = searchQuery.toLowerCase().trim();
      if (!q) return true;
      return (
        s.title.toLowerCase().includes(q) ||
        s.artist.toLowerCase().includes(q) ||
        s.album.toLowerCase().includes(q) ||
        s.folder.toLowerCase().includes(q)
      );
    });

    switch (sortOption) {
      case 'title-asc':
        return list.sort((a, b) => a.title.localeCompare(b.title));
      case 'title-desc':
        return list.sort((a, b) => b.title.localeCompare(a.title));
      case 'recent':
        return list.sort((a, b) => b.dateAdded - a.dateAdded);
      case 'most-played':
        return list.sort((a, b) => (b.playCount || 0) - (a.playCount || 0));
      default:
        return list;
    }
  }, [visibleSongs, searchQuery, sortOption]);

  const foldersMap = useMemo(() => {
    const map = new Map<string, Song[]>();
    visibleSongs.forEach((song) => {
      const folderName = song.folder || 'Music';
      const existing = map.get(folderName) || [];
      existing.push(song);
      map.set(folderName, existing);
    });
    return map;
  }, [visibleSongs]);

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const mins = Math.floor(secs / 60);
    const remainingSecs = Math.floor(secs % 60);
    return `${mins}:${remainingSecs < 10 ? '0' : ''}${remainingSecs}`;
  };

  // Reusable Song Item Renderer with Lyrics indicator & live Neon lyrics when playing
  const renderSongItem = (song: Song, extraBadge?: React.ReactNode) => {
    const isCurrent = currentSongId === song.id;
    return (
      <div
        key={song.id}
        className={`group flex items-center justify-between p-2.5 rounded-xl border transition-all duration-200 ${
          isCurrent
            ? 'bg-[#0c0c16] border-zinc-700'
            : 'bg-[#07070b] hover:bg-[#0c0c12] border-[#13131b]'
        }`}
        style={isCurrent ? { borderColor: currentTheme.color } : {}}
      >
        <div
          className="flex items-center space-x-3 flex-1 min-w-0 cursor-pointer"
          onClick={() => handlePlaySong(song)}
        >
          <div
            className="w-10 h-10 rounded-lg flex-none flex items-center justify-center relative overflow-hidden"
            style={{ background: song.artwork || '#111118' }}
          >
            {isCurrent && isPlaying ? (
              <div
                className="w-2.5 h-2.5 rounded-full animate-ping"
                style={{ backgroundColor: currentTheme.color }}
              />
            ) : (
              <Disc className="w-5 h-5 text-zinc-400 group-hover:scale-110 transition-transform" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <p
              className="text-xs font-semibold truncate leading-tight"
              style={{ color: isCurrent ? currentTheme.color : '#ffffff' }}
            >
              {song.title}
            </p>

            <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
              <span className="text-[11px] text-zinc-400 truncate max-w-[130px]">
                {song.artist}
              </span>

              {/* Requirement: songs that have lyrics will have lyrics written in small letters under the names */}
              {song.lyrics && (
                <span className="text-[9px] font-bold text-zinc-400 bg-[#14141e] px-1.5 py-0.2 rounded border border-[#222230] inline-flex items-center gap-0.5">
                  <FileText className="w-2.5 h-2.5 text-zinc-400" /> lyrics
                </span>
              )}

              {extraBadge}
            </div>

            {/* Requirement: when you play the song, the lyrics appear in neon color under the song */}
            {isCurrent && song.lyrics && currentLyricLine && (
              <p
                className="text-[11px] font-bold truncate mt-1 animate-pulse flex items-center gap-1"
                style={{
                  color: currentTheme.color,
                  textShadow: `0 0 8px ${currentTheme.glowRgba}`
                }}
              >
                <span>♪</span> {currentLyricLine}
              </p>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center space-x-1 pl-2">
          <button
            onClick={() => toggleFavorite(song.id)}
            className="p-1.5 text-zinc-500 hover:text-pink-500 transition-colors"
          >
            <Heart
              className={`w-3.5 h-3.5 ${
                song.isFavorite ? 'fill-pink-500 text-pink-500' : ''
              }`}
            />
          </button>
          <button
            onClick={() => addToQueue(song.id, activeQueueId === 'A' ? 'B' : 'A')}
            className="p-1.5 text-[10px] font-bold text-zinc-500 hover:text-white transition-colors"
            title={`Add to Queue ${activeQueueId === 'A' ? 'B' : 'A'}`}
          >
            +Q{activeQueueId === 'A' ? 'B' : 'A'}
          </button>
          {!song.isHidden ? (
            <button
              onClick={() => hideSong(song.id)}
              className="p-1.5 text-zinc-600 hover:text-zinc-300 transition-colors"
              title="Hide song"
            >
              <EyeOff className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={() => restoreSong(song.id)}
              className="p-1.5 text-zinc-400 hover:text-white transition-colors"
              title="Restore song"
            >
              <Eye className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-black text-white selection:bg-cyan-500/20">
      {/* Hidden Audio Element with Event Listeners & Error Recovery */}
      <audio
        ref={audioRef}
        src={currentSong?.url ? currentSong.url : undefined}
        preload="auto"
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onError={async () => {
          console.warn('Audio tag load error, regenerating offline synth audio...');
          if (currentSong && currentSong.id.startsWith('track-')) {
            const freshUrl = await generateSynthAudio(
              getStyleForSong(currentSong),
              32,
              `${currentSong.id}-${Date.now()}`
            );
            setSongs((prev) =>
              prev.map((s) => (s.id === currentSong.id ? { ...s, url: freshUrl } : s))
            );
            if (audioRef.current) {
              audioRef.current.src = freshUrl;
              audioRef.current.load();
              if (isPlaying) {
                audioRef.current.play().catch(console.warn);
              }
            }
          }
        }}
      />

      {/* Main Mobile Frame Container */}
      <div className="relative flex flex-col h-full w-full max-w-md mx-auto bg-black border-x border-[#121217] shadow-2xl">

        {/* TOP HEADER */}
        <header className="flex-none px-4 pt-3 pb-2 bg-black/95 backdrop-blur-md z-20 border-b border-[#14141c]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2.5">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center border transition-all duration-300"
                style={{
                  borderColor: currentTheme.color,
                  backgroundColor: '#0a0a0e',
                  boxShadow: `0 0 10px ${currentTheme.glowRgba}`
                }}
              >
                <Disc className="w-4 h-4 animate-spin-slow" style={{ color: currentTheme.color }} />
              </div>
              <div>
                <h1 className="text-lg font-extrabold tracking-wider text-white flex items-center gap-1.5">
                  NEON<span style={{ color: currentTheme.color }}>WAVE</span>
                </h1>
              </div>
            </div>

            {/* Right Header Action Icons */}
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setActiveQueueId(activeQueueId === 'A' ? 'B' : 'A')}
                className="px-2.5 py-1 rounded-full text-xs font-bold transition-all border flex items-center gap-1.5"
                style={{
                  backgroundColor: '#0c0c12',
                  borderColor: currentTheme.color,
                  color: currentTheme.color,
                  boxShadow: `0 0 8px ${currentTheme.glowRgba}`
                }}
                title="Switch between Queue A and Queue B"
              >
                <ListMusic className="w-3.5 h-3.5" />
                <span>QUEUE {activeQueueId}</span>
              </button>

              <button
                onClick={handleScanDeviceStorage}
                disabled={isScanning}
                className="p-1.5 text-zinc-400 hover:text-white transition-colors relative"
                title="Scan device storage & categorize by album"
              >
                <FolderSync
                  className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`}
                  style={isScanning ? { color: currentTheme.color } : {}}
                />
              </button>

              <button
                onClick={() => setViewMode(viewMode === 'list' ? 'grid' : 'list')}
                className="p-1.5 text-zinc-400 hover:text-white transition-colors"
                title="Toggle List/Grid View"
              >
                {viewMode === 'list' ? <LayoutGrid className="w-4 h-4" /> : <LayoutList className="w-4 h-4" />}
              </button>

              <button
                onClick={() => setIsDownloadModalOpen(true)}
                className="px-2 py-1 rounded-lg text-xs font-bold text-white transition-all flex items-center gap-1 border border-[#1e1e2d] bg-[#0d0d16] hover:bg-[#131320]"
                style={{
                  borderColor: currentTheme.color,
                  boxShadow: `0 0 8px ${currentTheme.glowRgba}`,
                }}
                title="Download APK / Install App"
              >
                <Download className="w-3.5 h-3.5" style={{ color: currentTheme.color }} />
                <span>Install</span>
              </button>

              <button
                onClick={() => setIsSettingsOpen(true)}
                className="p-1.5 text-zinc-400 hover:text-white transition-colors"
                title="Settings"
              >
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* 6 MAIN SECTIONS NAVIGATION TABS (In exact requested order: 1. All Songs, 2. Folders, 3. Playlists, 4. Hidden Albums, 5. Most Played, 6. Not Played for Long Time) */}
          <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar pb-2">
            {[
              { id: 'all', label: 'All Songs' },
              { id: 'folders', label: 'Folders' },
              { id: 'playlists', label: 'Playlists' },
              { id: 'hidden', label: 'Hidden Albums' },
              { id: 'most-played', label: 'Most Played' },
              { id: 'not-played', label: 'Not Played for Long Time' }
            ].map((tab) => {
              const isSelected = currentTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setCurrentTab(tab.id as MainTab);
                    setSelectedFolder(null);
                    setSelectedPlaylistId(null);
                  }}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-200 border ${
                    isSelected
                      ? 'border-transparent text-black font-bold'
                      : 'border-[#1b1b24] text-zinc-400 hover:text-white bg-[#0b0b10]'
                  }`}
                  style={
                    isSelected
                      ? {
                          backgroundColor: currentTheme.color,
                          boxShadow: `0 0 12px ${currentTheme.glowRgba}`,
                        }
                      : {}
                  }
                >
                  {tab.label}
                  {tab.id === 'hidden' && hiddenSongs.length > 0 && (
                    <span className="ml-1 px-1.5 py-0.2 text-[10px] bg-red-950 text-red-300 rounded-full">
                      {hiddenSongs.length}
                    </span>
                  )}
                  {tab.id === 'not-played' && notPlayedSongs.length > 0 && (
                    <span className="ml-1 px-1.5 py-0.2 text-[10px] bg-[#1a1826] text-amber-300 rounded-full">
                      {notPlayedSongs.length}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* UNIVERSAL SEARCH BAR: "The search option should be everywhere. So that when I go to any part of the playlist or folder, I can search" */}
          <div className="pt-1 pb-1 flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-zinc-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  selectedFolder
                    ? `Search in folder: ${selectedFolder}...`
                    : selectedPlaylistId
                    ? `Search in playlist...`
                    : currentTab === 'folders'
                    ? 'Search folders & tracks...'
                    : currentTab === 'playlists'
                    ? 'Search playlists & tracks...'
                    : currentTab === 'hidden'
                    ? 'Search hidden tracks...'
                    : currentTab === 'most-played'
                    ? 'Search most played...'
                    : currentTab === 'not-played'
                    ? 'Search unplayed & forgotten tracks...'
                    : 'Search everywhere (title, artist, album)...'
                }
                className="w-full bg-[#09090f] border border-[#1b1b28] rounded-xl pl-8 pr-7 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors"
                style={{ borderColor: searchQuery ? currentTheme.color : undefined }}
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2 text-zinc-500 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Sort Dropdown */}
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value as SortOption)}
              className="bg-[#09090f] border border-[#1b1b28] text-zinc-400 text-xs rounded-xl px-2 py-1.5 focus:outline-none"
            >
              <option value="title-asc">A–Z</option>
              <option value="title-desc">Z–A</option>
              <option value="recent">Recent</option>
              <option value="most-played">Plays</option>
            </select>

            {/* Import file button */}
            <label
              className="cursor-pointer bg-[#0e0e16] hover:bg-[#161622] border border-[#1f1f2c] text-zinc-300 p-2 rounded-xl flex items-center justify-center transition-colors flex-none"
              title="Import audio files"
            >
              <Upload className="w-3.5 h-3.5" />
              <input
                type="file"
                accept="audio/*"
                multiple
                className="hidden"
                onChange={handleLocalAudioUpload}
              />
            </label>
          </div>
        </header>
 
        {/* Floating Scan Notification Toast */}
        {scanToast && (
          <div
            className="mx-4 mt-2 p-2.5 rounded-xl border flex items-center justify-between text-xs z-30 transition-all animate-fadeIn"
            style={{
              backgroundColor: '#0a0a12',
              borderColor: currentTheme.color,
              boxShadow: `0 0 16px ${currentTheme.glowRgba}`
            }}
          >
            <div className="flex items-center space-x-2.5 min-w-0 flex-1">
              <Sparkles className="w-4 h-4 flex-none" style={{ color: currentTheme.color }} />
              <div className="min-w-0 flex-1">
                <p className="font-bold text-white truncate">{scanToast.message}</p>
                {scanToast.sub && (
                  <p className="text-[11px] text-zinc-300 truncate mt-0.5">{scanToast.sub}</p>
                )}
              </div>
            </div>
            <button
              onClick={() => setScanToast(null)}
              className="ml-2 text-zinc-500 hover:text-white text-xs font-bold px-1"
            >
              ✕
            </button>
          </div>
        )}

        {/* MAIN CONTENT AREA */}
        <main className="flex-1 overflow-y-auto px-4 py-3 bg-black">
          {/* TAB 1: ALL SONGS */}
          {currentTab === 'all' && (
            <div>
              {displayedAllSongs.length === 0 ? (
                <div className="py-16 text-center text-zinc-500 text-xs">
                  <Disc className="w-10 h-10 mx-auto mb-2 text-zinc-700 animate-spin-slow" />
                  No songs match your search.
                </div>
              ) : viewMode === 'list' ? (
                <div className="space-y-1.5">
                  {displayedAllSongs.map((song) => renderSongItem(song))}
                </div>
              ) : (
                /* Grid View */
                <div className="grid grid-cols-2 gap-2.5">
                  {displayedAllSongs.map((song) => {
                    const isCurrent = currentSongId === song.id;
                    return (
                      <div
                        key={song.id}
                        onClick={() => handlePlaySong(song)}
                        className="p-2.5 rounded-xl border bg-[#08080d] hover:bg-[#0d0d15] transition-all cursor-pointer flex flex-col justify-between"
                        style={{ borderColor: isCurrent ? currentTheme.color : '#14141e' }}
                      >
                        <div
                          className="w-full aspect-square rounded-lg flex items-center justify-center mb-2 relative"
                          style={{ background: song.artwork || '#111118' }}
                        >
                          <Disc className="w-8 h-8 text-zinc-500" />
                          {isCurrent && isPlaying && (
                            <span
                              className="absolute top-2 right-2 w-2.5 h-2.5 rounded-full"
                              style={{ backgroundColor: currentTheme.color, boxShadow: `0 0 8px ${currentTheme.color}` }}
                            />
                          )}
                        </div>
                        <div>
                          <p
                            className="text-xs font-bold truncate"
                            style={{ color: isCurrent ? currentTheme.color : '#fff' }}
                          >
                            {song.title}
                          </p>
                          <div className="flex items-center justify-between text-[10px] text-zinc-400 mt-0.5">
                            <span className="truncate">{song.artist}</span>
                            {song.lyrics && (
                              <span className="text-[8px] uppercase font-bold text-zinc-500 bg-[#161622] px-1 rounded">
                                lyrics
                              </span>
                            )}
                          </div>
                          {isCurrent && song.lyrics && currentLyricLine && (
                            <p
                              className="text-[10px] font-bold truncate mt-1 animate-pulse"
                              style={{ color: currentTheme.color }}
                            >
                              ♪ {currentLyricLine}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: FOLDERS (With "Not played for long time" filter option & Universal Search) */}
          {currentTab === 'folders' && (
            <div className="space-y-2.5">
              {!selectedFolder && (
                <div className="p-3 bg-[#0a0a12] border border-[#191928] rounded-xl flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" style={{ color: currentTheme.color }} />
                      Smart Album Folders
                    </p>
                    <p className="text-[10px] text-zinc-400 truncate">
                      Auto-categorizes all local audio into folders using album metadata
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 flex-none">
                    <button
                      onClick={handleScanDeviceStorage}
                      disabled={isScanning}
                      className="px-2.5 py-1.5 rounded-lg text-[11px] font-bold border border-zinc-700 bg-[#12121a] hover:border-zinc-500 text-zinc-200 flex items-center gap-1 transition-all"
                      title="Scan storage directory"
                    >
                      <FolderSync className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} style={{ color: currentTheme.color }} />
                      Scan
                    </button>
                    <button
                      onClick={handleSmartCategorizeAll}
                      disabled={isScanning}
                      className="px-2.5 py-1.5 rounded-lg text-[11px] font-bold text-black flex items-center gap-1 transition-all"
                      style={{ backgroundColor: currentTheme.color }}
                      title="Re-categorize all songs by album metadata"
                    >
                      <Sparkles className="w-3.5 h-3.5 fill-black" />
                      Auto-Group
                    </button>
                  </div>
                </div>
              )}

              {/* Inside a Selected Folder View */}
              {selectedFolder ? (
                <div>
                  <button
                    onClick={() => {
                      setSelectedFolder(null);
                      setFolderSubFilter('all');
                    }}
                    className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white mb-3"
                  >
                    <SkipBack className="w-3.5 h-3.5" /> Back to All Folders
                  </button>

                  {(() => {
                    const allInFolder = foldersMap.get(selectedFolder) || [];
                    const unplayedInFolder = allInFolder.filter(isNotPlayedLongTime);

                    const q = searchQuery.toLowerCase().trim();
                    const filteredList = (folderSubFilter === 'not-played' ? unplayedInFolder : allInFolder)
                      .filter((s) => !q || s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q));

                    return (
                      <div>
                        <div className="flex flex-col mb-3 bg-[#0a0a10] p-3 rounded-xl border border-[#171722] gap-2.5">
                          <div className="flex items-center justify-between">
                            <div className="min-w-0 flex-1">
                              <h2 className="text-sm font-bold text-white flex items-center gap-2 truncate">
                                <FolderIcon className="w-4 h-4 flex-none" style={{ color: currentTheme.color }} />
                                <span className="truncate">{selectedFolder}</span>
                              </h2>
                              <p className="text-[11px] text-zinc-400 mt-0.5">
                                {allInFolder.length} tracks • {unplayedInFolder.length} not played recently
                              </p>
                            </div>
                            <button
                              onClick={() => {
                                const target = folderSubFilter === 'not-played' ? unplayedInFolder : allInFolder;
                                if (target.length > 0) {
                                  if (activeQueueId === 'A') setQueueA(target.map((s) => s.id));
                                  else setQueueB(target.map((s) => s.id));
                                  handlePlaySong(target[0]);
                                }
                              }}
                              className="px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 text-black flex-none"
                              style={{ backgroundColor: currentTheme.color }}
                            >
                              <Play className="w-3.5 h-3.5 fill-black" /> Play All
                            </button>
                          </div>

                          {/* Requirement: "The same option will be there in playlists, folders as well" -> Not played for long time filter inside folders */}
                          <div className="flex items-center gap-2 pt-1 border-t border-[#151520]">
                            <button
                              onClick={() => setFolderSubFilter('all')}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                                folderSubFilter === 'all'
                                  ? 'text-black font-extrabold'
                                  : 'text-zinc-400 bg-[#12121a] hover:text-white'
                              }`}
                              style={folderSubFilter === 'all' ? { backgroundColor: currentTheme.color } : {}}
                            >
                              All Songs ({allInFolder.length})
                            </button>
                            <button
                              onClick={() => setFolderSubFilter('not-played')}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all ${
                                folderSubFilter === 'not-played'
                                  ? 'text-black font-extrabold'
                                  : 'text-zinc-400 bg-[#12121a] hover:text-white'
                              }`}
                              style={folderSubFilter === 'not-played' ? { backgroundColor: currentTheme.color } : {}}
                            >
                              <History className="w-3 h-3" />
                              Not Played for Long Time ({unplayedInFolder.length})
                            </button>
                          </div>
                        </div>

                        {filteredList.length === 0 ? (
                          <div className="py-12 text-center text-zinc-500 text-xs">
                            {folderSubFilter === 'not-played'
                              ? 'All songs in this folder have been played recently!'
                              : 'No songs match your search in this folder.'}
                          </div>
                        ) : (
                          <div className="space-y-1.5">
                            {filteredList.map((song) =>
                              renderSongItem(
                                song,
                                isNotPlayedLongTime(song) ? (
                                  <span className="text-[9px] text-amber-300 bg-amber-950/40 px-1 rounded">
                                    {formatLastPlayed(song)}
                                  </span>
                                ) : undefined
                              )
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              ) : (
                /* Folders List (with universal search filtering) */
                <div className="space-y-2">
                  {Array.from(foldersMap.entries())
                    .filter(([folderName]) => {
                      const q = searchQuery.toLowerCase().trim();
                      if (!q) return true;
                      return (
                        folderName.toLowerCase().includes(q) ||
                        (foldersMap.get(folderName) || []).some(
                          (s) => s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q)
                        )
                      );
                    })
                    .map(([folderName, folderSongs]) => {
                      const unplayedCount = folderSongs.filter(isNotPlayedLongTime).length;
                      return (
                        <div
                          key={folderName}
                          onClick={() => {
                            setSelectedFolder(folderName);
                            setFolderSubFilter('all');
                          }}
                          className="flex items-center justify-between p-3.5 rounded-xl border border-[#14141e] bg-[#08080d] hover:bg-[#0d0d15] cursor-pointer transition-all"
                        >
                          <div className="flex items-center space-x-3 min-w-0 flex-1">
                            <div className="p-2 rounded-lg bg-[#11111a] flex-none">
                              <FolderIcon className="w-5 h-5" style={{ color: currentTheme.color }} />
                            </div>
                            <div className="min-w-0 flex-1 pr-2">
                              <h3 className="text-xs font-bold text-white truncate">{folderName}</h3>
                              <div className="flex items-center gap-1.5 text-[11px] text-zinc-400 mt-0.5">
                                <span>{folderSongs.length} songs</span>
                                {unplayedCount > 0 && (
                                  <>
                                    <span>•</span>
                                    <span className="text-amber-400/90 flex items-center gap-0.5">
                                      <History className="w-2.5 h-2.5" /> {unplayedCount} not played recently
                                    </span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (folderSongs.length > 0) {
                                if (activeQueueId === 'A') setQueueA(folderSongs.map((s) => s.id));
                                else setQueueB(folderSongs.map((s) => s.id));
                                handlePlaySong(folderSongs[0]);
                              }
                            }}
                            className="p-2 text-zinc-400 hover:text-white flex-none"
                            title="Play entire folder"
                          >
                            <Play className="w-4 h-4" style={{ color: currentTheme.color }} />
                          </button>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PLAYLISTS (With "Not played for long time" filter option & Universal Search) */}
          {currentTab === 'playlists' && (
            <div className="space-y-3">
              {/* Inside a Selected Playlist */}
              {selectedPlaylistId ? (
                (() => {
                  const pl = playlists.find((p) => p.id === selectedPlaylistId);
                  if (!pl) {
                    setSelectedPlaylistId(null);
                    return null;
                  }
                  const allPlSongs = songs.filter((s) => pl.songIds.includes(s.id) && !s.isHidden);
                  const unplayedPlSongs = allPlSongs.filter(isNotPlayedLongTime);

                  const q = searchQuery.toLowerCase().trim();
                  const filteredPlSongs = (playlistSubFilter === 'not-played' ? unplayedPlSongs : allPlSongs)
                    .filter((s) => !q || s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q));

                  return (
                    <div>
                      <button
                        onClick={() => {
                          setSelectedPlaylistId(null);
                          setPlaylistSubFilter('all');
                        }}
                        className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white mb-3"
                      >
                        <SkipBack className="w-3.5 h-3.5" /> Back to Playlists
                      </button>

                      <div className="flex flex-col mb-3 bg-[#0a0a10] p-3 rounded-xl border border-[#171722] gap-2.5">
                        <div className="flex items-center justify-between">
                          <div className="min-w-0 flex-1">
                            <h2 className="text-sm font-bold text-white flex items-center gap-2 truncate">
                              <ListMusic className="w-4 h-4 flex-none" style={{ color: currentTheme.color }} />
                              <span className="truncate">{pl.name}</span>
                            </h2>
                            <p className="text-[11px] text-zinc-400 mt-0.5">
                              {allPlSongs.length} tracks • {unplayedPlSongs.length} not played recently
                            </p>
                          </div>
                          <button
                            onClick={() => {
                              const target = playlistSubFilter === 'not-played' ? unplayedPlSongs : allPlSongs;
                              if (target.length > 0) {
                                if (activeQueueId === 'A') setQueueA(target.map((s) => s.id));
                                else setQueueB(target.map((s) => s.id));
                                handlePlaySong(target[0]);
                              }
                            }}
                            className="px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 text-black flex-none"
                            style={{ backgroundColor: currentTheme.color }}
                          >
                            <Play className="w-3.5 h-3.5 fill-black" /> Play All
                          </button>
                        </div>

                        {/* Requirement: "The same option will be there in playlists, folders as well" -> Not played for long time filter inside playlists */}
                        <div className="flex items-center gap-2 pt-1 border-t border-[#151520]">
                          <button
                            onClick={() => setPlaylistSubFilter('all')}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                              playlistSubFilter === 'all'
                                ? 'text-black font-extrabold'
                                : 'text-zinc-400 bg-[#12121a] hover:text-white'
                            }`}
                            style={playlistSubFilter === 'all' ? { backgroundColor: currentTheme.color } : {}}
                          >
                            All Tracks ({allPlSongs.length})
                          </button>
                          <button
                            onClick={() => setPlaylistSubFilter('not-played')}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all ${
                              playlistSubFilter === 'not-played'
                                ? 'text-black font-extrabold'
                                : 'text-zinc-400 bg-[#12121a] hover:text-white'
                            }`}
                            style={playlistSubFilter === 'not-played' ? { backgroundColor: currentTheme.color } : {}}
                          >
                            <History className="w-3 h-3" />
                            Not Played for Long Time ({unplayedPlSongs.length})
                          </button>
                        </div>
                      </div>

                      {filteredPlSongs.length === 0 ? (
                        <div className="py-12 text-center text-zinc-500 text-xs">
                          {playlistSubFilter === 'not-played'
                            ? 'All songs in this playlist have been played recently!'
                            : 'No songs in this playlist match your search.'}
                        </div>
                      ) : (
                        <div className="space-y-1.5">
                          {filteredPlSongs.map((song) =>
                            renderSongItem(
                              song,
                              isNotPlayedLongTime(song) ? (
                                <span className="text-[9px] text-amber-300 bg-amber-950/40 px-1 rounded">
                                  {formatLastPlayed(song)}
                                </span>
                              ) : undefined
                            )
                          )}
                        </div>
                      )}
                    </div>
                  );
                })()
              ) : (
                /* Playlists List View */
                <div>
                  <button
                    onClick={() => {
                      const name = prompt('Enter new playlist name:');
                      if (name && name.trim()) {
                        const newPl: Playlist = {
                          id: 'pl-' + Date.now(),
                          name: name.trim(),
                          songIds: [],
                          createdAt: Date.now()
                        };
                        setPlaylists([...playlists, newPl]);
                      }
                    }}
                    className="w-full py-2.5 mb-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 text-black transition-all"
                    style={{ backgroundColor: currentTheme.color, boxShadow: `0 0 10px ${currentTheme.glowRgba}` }}
                  >
                    <Plus className="w-4 h-4 stroke-[3]" /> Create New Playlist
                  </button>

                  <div className="space-y-2">
                    {playlists
                      .filter((pl) => {
                        const q = searchQuery.toLowerCase().trim();
                        if (!q) return true;
                        return (
                          pl.name.toLowerCase().includes(q) ||
                          pl.songIds.some((sId) => {
                            const song = songs.find((s) => s.id === sId);
                            return song && (song.title.toLowerCase().includes(q) || song.artist.toLowerCase().includes(q));
                          })
                        );
                      })
                      .map((pl) => {
                        const plSongs = songs.filter((s) => pl.songIds.includes(s.id) && !s.isHidden);
                        const unplayedInPl = plSongs.filter(isNotPlayedLongTime).length;
                        return (
                          <div
                            key={pl.id}
                            className="flex items-center justify-between p-3 rounded-xl border border-[#14141e] bg-[#08080d] hover:bg-[#0c0c14] transition-all"
                          >
                            <div
                              className="flex-1 cursor-pointer min-w-0 pr-2"
                              onClick={() => {
                                setSelectedPlaylistId(pl.id);
                                setPlaylistSubFilter('all');
                              }}
                            >
                              <h4 className="text-xs font-bold text-white truncate">{pl.name}</h4>
                              <div className="flex items-center gap-1.5 text-[11px] text-zinc-400 mt-0.5">
                                <span>{plSongs.length} tracks</span>
                                {unplayedInPl > 0 && (
                                  <>
                                    <span>•</span>
                                    <span className="text-amber-400/90 flex items-center gap-0.5">
                                      <History className="w-2.5 h-2.5" /> {unplayedInPl} not played recently
                                    </span>
                                  </>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center space-x-1 flex-none">
                              <button
                                onClick={() => {
                                  if (plSongs.length > 0) {
                                    if (activeQueueId === 'A') setQueueA(plSongs.map((s) => s.id));
                                    else setQueueB(plSongs.map((s) => s.id));
                                    handlePlaySong(plSongs[0]);
                                  }
                                }}
                                className="p-1.5 text-zinc-400 hover:text-white"
                                title="Play playlist"
                              >
                                <Play className="w-3.5 h-3.5" style={{ color: currentTheme.color }} />
                              </button>
                              <button
                                onClick={() => {
                                  const name = prompt('Rename playlist:', pl.name);
                                  if (name && name.trim()) {
                                    setPlaylists(
                                      playlists.map((p) => (p.id === pl.id ? { ...p, name: name.trim() } : p))
                                    );
                                  }
                                }}
                                className="p-1.5 text-zinc-500 hover:text-white"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`Delete playlist "${pl.name}"?`)) {
                                    setPlaylists(playlists.filter((p) => p.id !== pl.id));
                                  }
                                }}
                                className="p-1.5 text-zinc-500 hover:text-red-400"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: HIDDEN ALBUMS & SONGS */}
          {currentTab === 'hidden' && (
            <div className="space-y-2">
              <div className="p-3 bg-[#0d0910] border border-[#261520] rounded-xl text-xs text-zinc-400">
                <p className="font-semibold text-zinc-200 flex items-center gap-1.5 mb-1">
                  <EyeOff className="w-3.5 h-3.5 text-red-400" /> Hidden Music Section
                </p>
                Songs here are excluded from All Songs, Folders, Most Played, and Not Played. They remain stored locally without being deleted.
              </div>

              {hiddenSongs
                .filter((s) => {
                  const q = searchQuery.toLowerCase().trim();
                  if (!q) return true;
                  return s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q);
                })
                .map((song) => (
                  <div
                    key={song.id}
                    className="flex items-center justify-between p-2.5 rounded-xl border border-[#1b141d] bg-[#0a070e]"
                  >
                    <div>
                      <p className="text-xs font-semibold text-zinc-300">{song.title}</p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="text-[11px] text-zinc-500">{song.artist}</span>
                        {song.lyrics && (
                          <span className="text-[8px] uppercase text-zinc-500 bg-[#161219] px-1 rounded">
                            lyrics
                          </span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => restoreSong(song.id)}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold border border-zinc-700 hover:border-zinc-400 text-zinc-300 hover:text-white flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" /> Restore
                    </button>
                  </div>
                ))}
            </div>
          )}

          {/* TAB 5: AUTOMATIC MOST PLAYED SECTION */}
          {currentTab === 'most-played' && (
            <div className="space-y-2">
              <div className="p-3 bg-[#080b12] border border-[#111a26] rounded-xl text-xs text-zinc-400 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-zinc-200 flex items-center gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5" style={{ color: currentTheme.color }} />
                    Listening History Tracking
                  </p>
                  <p className="text-[10px] text-zinc-500 mt-0.5">
                    Updated automatically when tracks are listened to for over 10 seconds.
                  </p>
                </div>
              </div>

              {mostPlayedSongs
                .filter((s) => {
                  const q = searchQuery.toLowerCase().trim();
                  if (!q) return true;
                  return s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q);
                })
                .map((song, idx) => (
                  <div
                    key={song.id}
                    onClick={() => handlePlaySong(song)}
                    className="flex items-center justify-between p-2.5 rounded-xl border border-[#14141e] bg-[#07070b] hover:bg-[#0c0c12] cursor-pointer"
                  >
                    <div className="flex items-center space-x-3 min-w-0 flex-1">
                      <span
                        className="w-5 text-center text-xs font-bold flex-none"
                        style={{ color: idx < 3 ? currentTheme.color : '#666' }}
                      >
                        #{idx + 1}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold text-white truncate">{song.title}</p>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[11px] text-zinc-400 truncate">{song.artist}</span>
                          {song.lyrics && (
                            <span className="text-[8px] uppercase text-zinc-400 bg-[#161622] px-1 rounded">
                              lyrics
                            </span>
                          )}
                        </div>
                        {currentSongId === song.id && song.lyrics && currentLyricLine && (
                          <p className="text-[10px] font-bold truncate mt-1 animate-pulse" style={{ color: currentTheme.color }}>
                            ♪ {currentLyricLine}
                          </p>
                        )}
                      </div>
                    </div>
                    <span
                      className="text-xs font-bold px-2 py-0.5 rounded-full bg-[#12121a] flex-none"
                      style={{ color: currentTheme.color }}
                    >
                      {song.playCount} plays
                    </span>
                  </div>
                ))}
            </div>
          )}

          {/* TAB 6: NOT PLAYED FOR LONG TIME SECTION (Requirement: "After the Most played option, give an option not played for long time") */}
          {currentTab === 'not-played' && (
            <div className="space-y-3">
              <div className="p-3.5 bg-[#0b0a14] border border-[#1c182a] rounded-xl flex items-center justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <History className="w-4 h-4 flex-none" style={{ color: currentTheme.color }} />
                    <h3 className="text-xs font-bold text-white">Not Played for Long Time</h3>
                  </div>
                  <p className="text-[10px] text-zinc-400 mt-0.5">
                    {notPlayedSongs.length} songs you haven't listened to recently or are unplayed
                  </p>
                </div>
                {notPlayedSongs.length > 0 && (
                  <button
                    onClick={() => {
                      if (activeQueueId === 'A') setQueueA(notPlayedSongs.map((s) => s.id));
                      else setQueueB(notPlayedSongs.map((s) => s.id));
                      handlePlaySong(notPlayedSongs[0]);
                    }}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold text-black flex items-center gap-1.5 flex-none transition-transform active:scale-95"
                    style={{ backgroundColor: currentTheme.color }}
                  >
                    <Play className="w-3.5 h-3.5 fill-black" /> Play All
                  </button>
                )}
              </div>

              {(() => {
                const q = searchQuery.toLowerCase().trim();
                const filtered = notPlayedSongs.filter((s) => {
                  if (!q) return true;
                  return s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q);
                });

                if (filtered.length === 0) {
                  return (
                    <div className="py-16 text-center text-zinc-500 text-xs">
                      {searchQuery
                        ? 'No unplayed songs match your search.'
                        : 'All songs in your library have been listened to recently!'}
                    </div>
                  );
                }

                return (
                  <div className="space-y-1.5">
                    {filtered.map((song) =>
                      renderSongItem(
                        song,
                        <span
                          className="text-[9px] font-medium px-1.5 py-0.2 rounded bg-[#151522] text-amber-300"
                          style={song.playCount === 0 ? { color: currentTheme.color } : {}}
                        >
                          {formatLastPlayed(song)}
                        </span>
                      )
                    )}
                  </div>
                );
              })()}
            </div>
          )}
        </main>

        {/* MINI PLAYER BAR AT BOTTOM */}
        {currentSong && (
          <div
            onClick={() => setIsNowPlayingOpen(true)}
            className="flex-none px-3 py-2 bg-[#08080c] border-t border-[#171722] cursor-pointer z-30 transition-all"
            style={{
              boxShadow: isPlaying ? `0 -4px 15px ${currentTheme.glowRgba}` : undefined
            }}
          >
            {/* Mini Progress Bar */}
            <div className="w-full bg-[#161620] h-1 rounded-full overflow-hidden mb-2">
              <div
                className="h-full transition-all duration-150"
                style={{
                  width: `${(currentTime / (duration || 1)) * 100}%`,
                  backgroundColor: currentTheme.color
                }}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5 min-w-0 flex-1">
                {/* Artwork */}
                <div
                  className="w-9 h-9 rounded-lg flex-none flex items-center justify-center relative overflow-hidden"
                  style={{ background: currentSong.artwork || '#111118' }}
                >
                  <Disc className={`w-5 h-5 text-zinc-300 ${isPlaying ? 'animate-spin-slow' : ''}`} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-bold text-white truncate">{currentSong.title}</p>
                    {currentSong.lyrics && (
                      <span className="text-[8px] uppercase font-bold text-zinc-400 bg-[#161622] px-1 rounded flex-none">
                        lyrics
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-zinc-400 truncate">{currentSong.artist}</p>
                </div>
              </div>

              {/* Mini Waveform & Controls */}
              <div className="flex items-center space-x-2 flex-none" onClick={(e) => e.stopPropagation()}>
                <canvas
                  ref={miniVisualizerCanvasRef}
                  width={46}
                  height={18}
                  className="rounded"
                />

                <button
                  onClick={handlePrevious}
                  className="p-1 text-zinc-400 hover:text-white"
                >
                  <SkipBack className="w-4 h-4" />
                </button>

                <button
                  onClick={handleTogglePlayPause}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-black font-bold transition-transform active:scale-95"
                  style={{ backgroundColor: currentTheme.color }}
                >
                  {isPlaying ? <Pause className="w-4 h-4 fill-black" /> : <Play className="w-4 h-4 fill-black ml-0.5" />}
                </button>

                <button
                  onClick={handleNext}
                  className="p-1 text-zinc-400 hover:text-white"
                >
                  <SkipForward className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Requirement: Live lyrics in neon color under the player */}
            {currentSong.lyrics && currentLyricLine && (
              <div className="mt-1.5 pt-1 border-t border-[#14141e] flex items-center justify-between text-[11px]">
                <span
                  className="truncate font-bold flex items-center gap-1.5 animate-pulse"
                  style={{
                    color: currentTheme.color,
                    textShadow: `0 0 8px ${currentTheme.glowRgba}`
                  }}
                >
                  <span>♪</span> {currentLyricLine}
                </span>
                <span className="text-[9px] text-zinc-500 font-mono ml-2 uppercase flex-none">lyrics</span>
              </div>
            )}
          </div>
        )}

        {/* FULL NOW PLAYING SCREEN MODAL */}
        {isNowPlayingOpen && currentSong && (
          <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between p-6 overflow-y-auto max-w-md mx-auto animate-fadeIn">
            {/* Header: Collapse, Queue Selector & Lyrics Toggle */}
            <div className="flex items-center justify-between">
              <button
                onClick={() => setIsNowPlayingOpen(false)}
                className="p-2 text-zinc-400 hover:text-white rounded-full bg-[#0d0d14]"
              >
                <ChevronDown className="w-5 h-5" />
              </button>

              {/* Queue Switcher */}
              <div className="flex items-center bg-[#0d0d14] p-1 rounded-full border border-[#1d1d28]">
                <button
                  onClick={() => setActiveQueueId('A')}
                  className={`px-3 py-1 text-[11px] font-bold rounded-full transition-all ${
                    activeQueueId === 'A' ? 'text-black font-black' : 'text-zinc-400'
                  }`}
                  style={activeQueueId === 'A' ? { backgroundColor: currentTheme.color } : {}}
                >
                  QUEUE A
                </button>
                <button
                  onClick={() => setActiveQueueId('B')}
                  className={`px-3 py-1 text-[11px] font-bold rounded-full transition-all ${
                    activeQueueId === 'B' ? 'text-black font-black' : 'text-zinc-400'
                  }`}
                  style={activeQueueId === 'B' ? { backgroundColor: currentTheme.color } : {}}
                >
                  QUEUE B
                </button>
              </div>

              <div className="flex items-center space-x-1">
                <button
                  onClick={() => setIsEqualizerOpen(true)}
                  className="p-2 text-zinc-400 hover:text-white rounded-full bg-[#0d0d14]"
                  title="Equalizer"
                >
                  <Sliders className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsLyricsMode(!isLyricsMode)}
                  className={`p-2 rounded-full transition-all ${
                    isLyricsMode ? 'text-black' : 'text-zinc-400 bg-[#0d0d14]'
                  }`}
                  style={isLyricsMode ? { backgroundColor: currentTheme.color } : {}}
                  title="Toggle Synchronized Lyrics View"
                >
                  <FileText className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Center Area: Either Animated Artwork OR Synchronized Lyrics */}
            <div className="my-auto py-3 flex flex-col items-center justify-center">
              {isLyricsMode ? (
                /* SYNCHRONIZED LYRICS VIEW */
                <div className="w-full h-72 flex flex-col items-center relative">
                  <div className="w-full flex items-center justify-between pb-2 mb-2 border-b border-[#14141e] text-xs text-zinc-400">
                    <span className="font-semibold text-white flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5" style={{ color: currentTheme.color }} />
                      Synchronized Lyrics
                    </span>
                    <button
                      onClick={() => {
                        setEditedLyrics(currentSong.lyrics || '');
                        setIsLyricsEditorOpen(true);
                      }}
                      className="text-[11px] text-cyan-400 hover:underline"
                    >
                      Edit / Import LRC
                    </button>
                  </div>

                  <div
                    ref={lyricsContainerRef}
                    onScroll={handleLyricsUserScroll}
                    className="w-full h-full overflow-y-auto space-y-3.5 px-2 text-center no-scrollbar"
                  >
                    {parsedLyrics.length === 0 ? (
                      <div className="py-20 text-zinc-500 text-xs">
                        No timestamped lyrics for this track.<br />
                        Click "Edit / Import LRC" to add lyrics!
                      </div>
                    ) : (
                      parsedLyrics.map((line, idx) => {
                        const isActive = idx === activeLyricIndex;
                        return (
                          <p
                            key={idx}
                            ref={isActive ? activeLyricRef : null}
                            onClick={() => handleSeek(line.time)}
                            className={`transition-all duration-300 cursor-pointer font-medium select-none ${
                              isActive
                                ? 'text-sm font-bold scale-105'
                                : 'text-xs text-zinc-500 hover:text-zinc-300'
                            }`}
                            style={{
                              color: isActive ? currentTheme.color : undefined,
                              textShadow: isActive ? `0 0 12px ${currentTheme.color}` : undefined
                            }}
                          >
                            {line.text}
                          </p>
                        );
                      })
                    )}
                  </div>

                  {userIsScrollingLyrics && (
                    <button
                      onClick={syncLyricsToCurrent}
                      className="absolute bottom-2 px-3 py-1 rounded-full text-[11px] font-bold text-black shadow-lg transition-transform hover:scale-105"
                      style={{ backgroundColor: currentTheme.color }}
                    >
                      Sync to Current Line
                    </button>
                  )}
                </div>
              ) : (
                /* LIVE ANIMATION A: Animated Album Artwork with Pulsing Neon Rings */
                <div className="relative flex items-center justify-center">
                  <div
                    className={`absolute rounded-3xl transition-all duration-700 pointer-events-none ${
                      isPlaying ? 'opacity-80 scale-105' : 'opacity-20 scale-100'
                    }`}
                    style={{
                      width: '270px',
                      height: '270px',
                      border: `2px solid ${currentTheme.color}`,
                      boxShadow: `0 0 35px ${currentTheme.glowRgba}`,
                    }}
                  />

                  <div
                    className="w-64 h-64 rounded-2xl flex items-center justify-center relative overflow-hidden border border-[#1f1f2c]"
                    style={{ background: currentSong.artwork || '#0e0e16' }}
                  >
                    <Disc
                      className={`w-28 h-28 text-white/40 transition-transform duration-1000 ${
                        isPlaying ? 'animate-spin-slow scale-105' : 'scale-100'
                      }`}
                    />
                    <div
                      className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4"
                    >
                      <div className="w-full">
                        <span className="text-[10px] tracking-wider font-bold text-zinc-400 uppercase">
                          {currentSong.album}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Song Meta, Favorite & Queue Badge */}
            <div className="w-full">
              <div className="flex items-center justify-between mb-3">
                <div className="min-w-0 flex-1 pr-3">
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-black text-white truncate leading-tight">
                      {currentSong.title}
                    </h2>
                    {currentSong.lyrics && (
                      <span className="text-[9px] font-bold text-zinc-400 bg-[#161622] px-1.5 py-0.5 rounded border border-[#242436] flex-none">
                        lyrics
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-zinc-400 truncate mt-0.5">{currentSong.artist}</p>
                </div>
                <button
                  onClick={() => toggleFavorite(currentSong.id)}
                  className="p-2 text-zinc-400 hover:text-pink-500 transition-colors"
                >
                  <Heart
                    className={`w-5 h-5 ${
                      currentSong.isFavorite ? 'fill-pink-500 text-pink-500' : ''
                    }`}
                  />
                </button>
              </div>

              {/* LIVE ANIMATION B: Animated Audio Waveform Equalizer Canvas */}
              <div className="w-full mb-3 flex flex-col items-center">
                <canvas
                  ref={visualizerCanvasRef}
                  width={340}
                  height={32}
                  className="w-full rounded-lg"
                />
              </div>

              {/* Seekbar */}
              <div className="space-y-1 mb-3">
                <input
                  type="range"
                  min="0"
                  max={duration || 1}
                  step="0.1"
                  value={currentTime}
                  onChange={(e) => handleSeek(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-[#171724] rounded-lg appearance-none cursor-pointer accent-current"
                  style={{ color: currentTheme.color }}
                />
                <div className="flex justify-between text-[11px] text-zinc-500 font-mono">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>

              {/* Main Playback Controls */}
              <div className="flex items-center justify-between mb-2">
                <button
                  onClick={() => setIsShuffle(!isShuffle)}
                  className={`p-2 transition-colors ${
                    isShuffle ? 'text-white' : 'text-zinc-600 hover:text-zinc-400'
                  }`}
                  style={isShuffle ? { color: currentTheme.color } : {}}
                  title="Shuffle"
                >
                  <Shuffle className="w-4 h-4" />
                </button>

                <button
                  onClick={handlePrevious}
                  className="p-2 text-zinc-300 hover:text-white transition-colors"
                  title="Previous track"
                >
                  <SkipBack className="w-6 h-6" />
                </button>

                {/* Primary Play/Pause Button */}
                <button
                  onClick={handleTogglePlayPause}
                  className="w-14 h-14 rounded-full flex items-center justify-center text-black font-extrabold shadow-lg transition-transform active:scale-95"
                  style={{
                    backgroundColor: currentTheme.color,
                    boxShadow: `0 0 20px ${currentTheme.glowRgba}`
                  }}
                  title="Play/Pause"
                >
                  {isPlaying ? (
                    <Pause className="w-6 h-6 fill-black" />
                  ) : (
                    <Play className="w-6 h-6 fill-black ml-1" />
                  )}
                </button>

                <button
                  onClick={handleNext}
                  className="p-2 text-zinc-300 hover:text-white transition-colors"
                  title="Next track"
                >
                  <SkipForward className="w-6 h-6" />
                </button>

                <button
                  onClick={() => {
                    const modes: RepeatMode[] = ['off', 'all', 'one'];
                    const next = modes[(modes.indexOf(repeatMode) + 1) % modes.length];
                    setRepeatMode(next);
                  }}
                  className={`p-2 transition-colors ${
                    repeatMode !== 'off' ? 'text-white' : 'text-zinc-600 hover:text-zinc-400'
                  }`}
                  style={repeatMode !== 'off' ? { color: currentTheme.color } : {}}
                  title={`Repeat: ${repeatMode}`}
                >
                  {repeatMode === 'one' ? <Repeat1 className="w-4 h-4" /> : <Repeat className="w-4 h-4" />}
                </button>
              </div>

              {/* Requirement: "when you play the song, the lyrics of the song will appear in neon color under the play button of the song that has lyrics" */}
              {currentSong.lyrics && currentLyricLine && (
                <div
                  className="my-2 px-3 py-1.5 rounded-xl max-w-sm mx-auto text-center border backdrop-blur-md transition-all duration-300 animate-fadeIn"
                  style={{
                    backgroundColor: 'rgba(10, 10, 16, 0.9)',
                    borderColor: currentTheme.color,
                    boxShadow: isPlaying ? `0 0 14px ${currentTheme.glowRgba}` : 'none'
                  }}
                >
                  <p
                    className="text-xs font-black tracking-wide truncate animate-pulse"
                    style={{
                      color: currentTheme.color,
                      textShadow: `0 0 8px ${currentTheme.color}`
                    }}
                  >
                    ♪ {currentLyricLine}
                  </p>
                </div>
              )}

              {/* Bottom Quick Bar: Queue Drawer Toggle */}
              <div className="flex items-center justify-between pt-2 border-t border-[#13131c] text-xs text-zinc-400 mt-2">
                <button
                  onClick={() => setIsQueueDrawerOpen(!isQueueDrawerOpen)}
                  className="flex items-center gap-1.5 hover:text-white"
                >
                  <ListMusic className="w-3.5 h-3.5" style={{ color: currentTheme.color }} />
                  <span>View Queue ({currentQueueSongIds.length} tracks)</span>
                </button>

                <div className="flex items-center space-x-2">
                  <Volume2 className="w-3.5 h-3.5 text-zinc-500" />
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    className="w-16 h-1 bg-[#1a1a26] rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* EQUALIZER MODAL */}
        {isEqualizerOpen && (
          <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="w-full max-w-sm bg-[#09090e] border border-[#1c1c28] rounded-2xl p-5 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sliders className="w-4 h-4" style={{ color: currentTheme.color }} />
                  5-Band Graphic Equalizer
                </h3>
                <button
                  onClick={() => setIsEqualizerOpen(false)}
                  className="text-xs text-zinc-400 hover:text-white"
                >
                  Done
                </button>
              </div>

              <div className="flex gap-1.5 overflow-x-auto no-scrollbar mb-5">
                {[
                  { id: 'flat', label: 'Flat', gains: [0, 0, 0, 0, 0] },
                  { id: 'bass', label: 'Bass Boost', gains: [6, 4, 1, 0, -1] },
                  { id: 'electro', label: 'Electronic', gains: [5, 2, -1, 3, 5] },
                  { id: 'rock', label: 'Rock', gains: [4, -1, -2, 2, 4] },
                  { id: 'vocal', label: 'Vocal', gains: [-2, 1, 5, 3, -1] }
                ].map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => {
                      setEqPreset(preset.id);
                      setEqGains(preset.gains);
                    }}
                    className={`px-2.5 py-1 text-[11px] rounded-lg border font-semibold whitespace-nowrap transition-all ${
                      eqPreset === preset.id
                        ? 'border-transparent text-black'
                        : 'border-[#1b1b24] text-zinc-400 bg-[#0d0d14]'
                    }`}
                    style={eqPreset === preset.id ? { backgroundColor: currentTheme.color } : {}}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              <div className="flex justify-between items-end h-36 px-2 mb-4">
                {['60Hz', '250Hz', '1kHz', '4kHz', '16kHz'].map((label, idx) => (
                  <div key={label} className="flex flex-col items-center h-full justify-between">
                    <span className="text-[10px] text-zinc-500 font-mono">
                      {eqGains[idx] > 0 ? `+${eqGains[idx]}` : eqGains[idx]}dB
                    </span>
                    <input
                      type="range"
                      min="-12"
                      max="12"
                      value={eqGains[idx]}
                      onChange={(e) => {
                        const newGains = [...eqGains];
                        newGains[idx] = parseInt(e.target.value, 10);
                        setEqGains(newGains);
                        setEqPreset('custom');
                      }}
                      className="h-24 w-1.5 appearance-none bg-[#191926] rounded-full cursor-pointer -rotate-90 origin-center"
                    />
                    <span className="text-[10px] text-zinc-400 font-semibold">{label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SETTINGS MODAL */}
        {isSettingsOpen && (
          <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="w-full max-w-sm bg-[#09090e] border border-[#1c1c28] rounded-2xl p-5 shadow-2xl max-h-[85vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Settings className="w-4 h-4" style={{ color: currentTheme.color }} />
                  NeonWave Settings
                </h3>
                <button
                  onClick={() => setIsSettingsOpen(false)}
                  className="text-xs text-zinc-400 hover:text-white"
                >
                  Close
                </button>
              </div>

              {/* Neon Accent Color Selector */}
              <div className="mb-4">
                <label className="text-xs font-semibold text-zinc-300 block mb-2">
                  Neon Accent Palette
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {THEMES.map((theme) => {
                    const isSelected = currentTheme.id === theme.id;
                    return (
                      <button
                        key={theme.id}
                        onClick={() => setCurrentTheme(theme)}
                        className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                          isSelected ? 'border-zinc-400 bg-[#12121c]' : 'border-[#171722] bg-[#0c0c12]'
                        }`}
                      >
                        <div
                          className="w-4 h-4 rounded-full border border-white/20"
                          style={{
                            backgroundColor: theme.color,
                            boxShadow: `0 0 8px ${theme.color}`
                          }}
                        />
                        <span className="text-white">{theme.name}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 ml-auto text-white" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Sleep Timer */}
              <div className="mb-4 pt-3 border-t border-[#14141e]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" /> Sleep Timer
                  </span>
                  {sleepTimerRemaining !== null && (
                    <span className="text-xs font-mono" style={{ color: currentTheme.color }}>
                      {formatTime(sleepTimerRemaining)} remaining
                    </span>
                  )}
                </div>
                <div className="flex gap-1.5">
                  {[15, 30, 45, 60].map((mins) => (
                    <button
                      key={mins}
                      onClick={() => setSleepTimerMinutes(sleepTimerMinutes === mins ? null : mins)}
                      className={`flex-1 py-1.5 text-xs rounded-lg border font-semibold transition-all ${
                        sleepTimerMinutes === mins
                          ? 'border-transparent text-black font-bold'
                          : 'border-[#1b1b24] text-zinc-400 bg-[#0d0d14]'
                      }`}
                      style={sleepTimerMinutes === mins ? { backgroundColor: currentTheme.color } : {}}
                    >
                      {mins}m
                    </button>
                  ))}
                  {sleepTimerMinutes !== null && (
                    <button
                      onClick={() => setSleepTimerMinutes(null)}
                      className="px-2 py-1.5 text-xs text-red-400 hover:text-red-300"
                    >
                      Off
                    </button>
                  )}
                </div>
              </div>

              {/* Automated Storage Scanner & Album Categorizer */}
              <div className="mb-4 pt-3 border-t border-[#14141e] space-y-2.5">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
                      <FolderSync className="w-3.5 h-3.5" style={{ color: currentTheme.color }} />
                      Auto-Scan Device Storage
                    </span>
                    <p className="text-[10px] text-zinc-500">
                      Detect new media on app resume & organize by album
                    </p>
                  </div>
                  <button
                    onClick={() => setAutoScanEnabled(!autoScanEnabled)}
                    className={`w-10 h-5 rounded-full transition-colors relative flex items-center px-0.5 ${
                      autoScanEnabled ? 'bg-cyan-500' : 'bg-zinc-800'
                    }`}
                    style={autoScanEnabled ? { backgroundColor: currentTheme.color } : {}}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-black transition-transform ${
                        autoScanEnabled ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => {
                      handleScanDeviceStorage();
                      setIsSettingsOpen(false);
                    }}
                    disabled={isScanning}
                    className="py-2 px-2.5 rounded-xl border border-zinc-700 bg-[#101018] hover:bg-[#161622] text-xs font-bold text-white flex items-center justify-center gap-1.5 transition-all"
                  >
                    <FolderSync className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} style={{ color: currentTheme.color }} />
                    Scan Storage
                  </button>
                  <button
                    onClick={() => {
                      handleSmartCategorizeAll();
                      setIsSettingsOpen(false);
                    }}
                    disabled={isScanning}
                    className="py-2 px-2.5 rounded-xl border border-zinc-700 bg-[#101018] hover:bg-[#161622] text-xs font-bold text-white flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Sparkles className="w-3.5 h-3.5" style={{ color: currentTheme.color }} />
                    Group Albums
                  </button>
                </div>
              </div>

              {/* Maintenance & Data Actions */}
              <div className="pt-3 border-t border-[#14141e] space-y-2">
                <button
                  onClick={() => {
                    setIsSettingsOpen(false);
                    setIsDownloadModalOpen(true);
                  }}
                  className="w-full py-2.5 px-3 rounded-xl border border-cyan-800/80 bg-[#0e1320] hover:bg-[#141a2c] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95"
                  style={{
                    borderColor: currentTheme.color,
                    boxShadow: `0 0 10px ${currentTheme.glowRgba}`,
                  }}
                >
                  <Download className="w-4 h-4" style={{ color: currentTheme.color }} />
                  Download APK / Install to Phone
                </button>

                <button
                  onClick={() => {
                    setSongs((prev) =>
                      prev.map((s) => ({ ...s, playCount: 0, lastPlayed: 0 }))
                    );
                    alert('Listening history cleared.');
                  }}
                  className="w-full py-2 px-3 rounded-xl border border-red-950/60 bg-red-950/20 text-red-400 hover:bg-red-950/30 text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Clear Listening History
                </button>

                <button
                  onClick={() => setShowAndroidInfoModal(true)}
                  className="w-full py-2 px-3 rounded-xl border border-[#1b1b28] bg-[#0c0c14] hover:bg-[#12121c] text-zinc-300 text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  <Smartphone className="w-3.5 h-3.5" style={{ color: currentTheme.color }} />
                  Android Native Architecture Info
                </button>
              </div>

              {/* Version & Info */}
              <div className="mt-5 text-center text-[10px] text-zinc-600">
                NeonWave v1.0.0 • Pure Black & Neon Minimalist Music Player<br />
                100% Free • Offline • Zero Ads
              </div>
            </div>
          </div>
        )}

        {/* LYRICS EDITOR MODAL */}
        {isLyricsEditorOpen && (
          <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="w-full max-w-sm bg-[#09090e] border border-[#1c1c28] rounded-2xl p-5 shadow-2xl">
              <h3 className="text-sm font-bold text-white mb-2">Edit / Import LRC Lyrics</h3>
              <p className="text-[11px] text-zinc-400 mb-3">
                Paste or edit LRC timestamped lines (e.g. [00:12.50] Lyric line).
              </p>
              <textarea
                value={editedLyrics}
                onChange={(e) => setEditedLyrics(e.target.value)}
                rows={10}
                className="w-full bg-[#050508] border border-[#1b1b26] rounded-xl p-3 text-xs font-mono text-zinc-200 focus:outline-none mb-3"
              />
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setIsLyricsEditorOpen(false)}
                  className="px-3 py-1.5 text-xs text-zinc-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (currentSongId) {
                      setSongs((prev) =>
                        prev.map((s) =>
                          s.id === currentSongId ? { ...s, lyrics: editedLyrics } : s
                        )
                      );
                    }
                    setIsLyricsEditorOpen(false);
                  }}
                  className="px-4 py-1.5 rounded-lg text-xs font-bold text-black"
                  style={{ backgroundColor: currentTheme.color }}
                >
                  Save Lyrics
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ANDROID ARCHITECTURE INFO MODAL */}
        {showAndroidInfoModal && (
          <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-[#09090e] border border-[#1c1c28] rounded-2xl p-5 shadow-2xl max-h-[85vh] overflow-y-auto text-xs text-zinc-300">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Smartphone className="w-4 h-4" style={{ color: currentTheme.color }} />
                  Android Kotlin & Jetpack Compose Source
                </h3>
                <button onClick={() => setShowAndroidInfoModal(false)} className="text-zinc-400 hover:text-white">
                  Close
                </button>
              </div>
              <p className="text-zinc-400 mb-3">
                The full native Android source code has been authored in this workspace under <code className="text-cyan-300">app/src/main/</code>:
              </p>
              <ul className="space-y-2 mb-4 text-zinc-400">
                <li>• <strong className="text-white">MainActivity.kt:</strong> Jetpack Compose UI with all 6 tabs (All Songs, Folders, Playlists, Hidden, Most Played, Not Played for Long Time), universal search, and lyrics display.</li>
                <li>• <strong className="text-white">NeonWaveMediaService.kt:</strong> AndroidX Media3 ExoPlayer + MediaSessionService for background playback and lock-screen controls.</li>
                <li>• <strong className="text-white">AutoMediaScanner.kt:</strong> Automatic MediaStore ContentObserver and album folder categorization.</li>
                <li>• <strong className="text-white">NeonWaveDatabase.kt:</strong> Room SQLite DB with persistent play history, timestamps, and playlists.</li>
              </ul>
              <div className="p-3 bg-[#0d0d16] rounded-xl border border-zinc-800 text-[11px]">
                Target device optimization: Samsung Galaxy A06 & all modern Android 8.0 - 15+ devices.
              </div>
            </div>
          </div>
        )}

        {/* DOWNLOAD & INSTALLATION MODAL */}
        <DownloadModal
          isOpen={isDownloadModalOpen}
          onClose={() => setIsDownloadModalOpen(false)}
          currentTheme={currentTheme}
          songs={songs}
        />

        {/* QUEUE DRAWER */}
        {isQueueDrawerOpen && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex flex-col justify-end">
            <div className="bg-[#0a0a0f] border-t border-[#1b1b28] rounded-t-2xl max-h-[70vh] flex flex-col p-4 max-w-md mx-auto w-full">
              <div className="flex items-center justify-between pb-3 border-b border-[#14141e] mb-2">
                <div className="flex items-center gap-2">
                  <ListMusic className="w-4 h-4" style={{ color: currentTheme.color }} />
                  <span className="text-xs font-bold text-white">Queue {activeQueueId}</span>
                  <span className="text-[11px] text-zinc-500">({currentQueueSongIds.length} tracks)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => {
                      if (activeQueueId === 'A') setQueueA([]);
                      else setQueueB([]);
                    }}
                    className="text-[11px] text-red-400 hover:text-red-300"
                  >
                    Clear Queue
                  </button>
                  <button
                    onClick={() => setIsQueueDrawerOpen(false)}
                    className="text-xs text-zinc-400 hover:text-white"
                  >
                    Done
                  </button>
                </div>
              </div>

              <div className="overflow-y-auto space-y-1.5 flex-1 pr-1">
                {currentQueueSongIds.length === 0 ? (
                  <div className="py-10 text-center text-zinc-500 text-xs">Queue is empty</div>
                ) : (
                  currentQueueSongIds.map((sId, index) => {
                    const song = songs.find((s) => s.id === sId);
                    if (!song) return null;
                    const isCurrent = song.id === currentSongId;
                    return (
                      <div
                        key={`${sId}-${index}`}
                        className={`flex items-center justify-between p-2 rounded-lg border text-xs ${
                          isCurrent
                            ? 'bg-[#12121f] border-zinc-700'
                            : 'bg-[#08080d] border-[#13131c]'
                        }`}
                      >
                        <div
                          className="flex items-center space-x-2.5 flex-1 min-w-0 cursor-pointer"
                          onClick={() => handlePlaySong(song)}
                        >
                          <span className="text-[10px] text-zinc-500 font-mono w-4">
                            {index + 1}
                          </span>
                          <div className="min-w-0 flex-1">
                            <p
                              className="font-semibold truncate"
                              style={{ color: isCurrent ? currentTheme.color : '#fff' }}
                            >
                              {song.title}
                            </p>
                            <p className="text-[10px] text-zinc-400 truncate">{song.artist}</p>
                          </div>
                        </div>

                        <button
                          onClick={() => removeFromQueue(song.id, activeQueueId)}
                          className="p-1 text-zinc-500 hover:text-red-400"
                          title="Remove from queue"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
