import { Song, Playlist } from './types';

export const INITIAL_SONGS: Song[] = [
  {
    id: 'track-1',
    title: 'Neon Horizon',
    artist: 'Kavinsky Pulse',
    album: 'Synthetic Overdrive',
    duration: 65,
    url: '', // will be initialized dynamically
    folder: 'Kavinsky Pulse — Synthetic Overdrive',
    dateAdded: Date.now() - 86400000 * 10,
    playCount: 14,
    lastPlayed: Date.now() - 3600000 * 2, // 2 hours ago
    isHidden: false,
    isFavorite: true,
    artwork: 'linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)',
    lyrics: `[00:00.00]Neon lights ignite the empty highway
[00:06.50]Glow of cyan mirrors in the rain
[00:12.00]Digital frequencies humming through the engine
[00:19.00]Cruising at one hundred in the midnight lane
[00:26.00]Hold the wheel, feel the bassline rising
[00:33.50]The city grid dissolves into the dark
[00:41.00]Infinite horizons on a neon screen
[00:49.00]We belong where electric shadows spark
[00:57.00]Neon horizon fade into the dawn`
  },
  {
    id: 'track-2',
    title: 'Cyber Drift',
    artist: 'Aethelgard 2088',
    album: 'Megacity Run',
    duration: 65,
    url: '',
    folder: 'Aethelgard 2088 — Megacity Run',
    dateAdded: Date.now() - 86400000 * 25,
    playCount: 4,
    lastPlayed: Date.now() - 86400000 * 18, // 18 days ago (Not played for a long time)
    isHidden: false,
    isFavorite: false,
    artwork: 'linear-gradient(135deg, #050505 0%, #1a0033 50%, #00334e 100%)',
    lyrics: `[00:00.00]Booting interface... telemetry online
[00:07.00]Holographic signs reflect across the glass
[00:14.50]Downshifts echoing between skyscrapers
[00:22.00]Through the neon rain we accelerate and pass
[00:30.00]Zero friction on the elevated track
[00:38.00]Electric pulse vibrating in the core
[00:46.00]Pushing beyond the speed of memory
[00:54.00]Nothing will be like it was before`
  },
  {
    id: 'track-3',
    title: 'Midnight Runner',
    artist: 'Stardust Drive',
    album: 'Nightcall Odyssey',
    duration: 65,
    url: '',
    folder: 'Stardust Drive — Nightcall Odyssey',
    dateAdded: Date.now() - 86400000 * 4,
    playCount: 22,
    lastPlayed: Date.now() - 3600000 * 4, // 4 hours ago
    isHidden: false,
    isFavorite: true,
    artwork: 'linear-gradient(135deg, #0b0c10 0%, #1f2833 50%, #001f3f 100%)',
    lyrics: `[00:00.00]Street lamps blinking in a rhythm slow
[00:08.00]Radio tuning through static frequencies
[00:16.00]A lost cassette tape playing from long ago
[00:24.00]Carrying echoes of nostalgic memories
[00:32.00]Midnight runner, destination nowhere
[00:40.00]Just the open asphalt and the purple sky
[00:48.00]Turn the volume high and breathe the air
[00:56.00]Watch the world go rushing by`
  },
  {
    id: 'track-4',
    title: 'Retro Dreamscape',
    artist: 'Lazer Sunset',
    album: 'Analog Dreams',
    duration: 65,
    url: '',
    folder: 'Lazer Sunset — Analog Dreams',
    dateAdded: Date.now() - 86400000 * 40,
    playCount: 2,
    lastPlayed: Date.now() - 86400000 * 28, // 28 days ago (Not played for long time)
    isHidden: false,
    isFavorite: false,
    artwork: 'linear-gradient(135deg, #110022 0%, #2b0938 50%, #0d1b2a 100%)',
    lyrics: `[00:00.00]Warm tape saturation fills the room
[00:08.50]Sun sinking down behind the wireframe grid
[00:17.00]In the amber glow of the CRT screen
[00:25.50]Remembering secrets that the evening hid
[00:34.00]Gentle breeze on an endless boulevard
[00:42.50]Time slows down when the chords begin to play
[00:51.00]Dreams rendered in sixteen bit color
[00:58.50]Floating till tomorrow comes our way`
  },
  {
    id: 'track-5',
    title: 'Echoes in the Grid',
    artist: 'Vapor Waveform',
    album: 'Sublevel Protocol',
    duration: 65,
    url: '',
    folder: 'Vapor Waveform — Sublevel Protocol',
    dateAdded: Date.now() - 86400000 * 35,
    playCount: 0,
    lastPlayed: 0, // Never played (Not played for long time)
    isHidden: false,
    isFavorite: false,
    artwork: 'linear-gradient(135deg, #02111b 0%, #083c5d 50%, #1d2731 100%)',
    lyrics: `[00:00.00]Sublevel corridors fading to gray
[00:07.50]Ghost in the mainframe waiting to start
[00:15.00]Pulses of light from a dormant relay
[00:23.00]Signals that echo directly to the heart
[00:31.00]Awakening the forgotten memory
[00:39.00]Synthesizer chords echoing through time`
  },
  {
    id: 'track-6',
    title: 'Solar Winds Over Tokyo',
    artist: 'Shinjuku Neon',
    album: 'Megacity Run',
    duration: 65,
    url: '',
    folder: 'Aethelgard 2088 — Megacity Run',
    dateAdded: Date.now() - 86400000 * 50,
    playCount: 1,
    lastPlayed: Date.now() - 86400000 * 42, // 42 days ago (Not played for long time)
    isHidden: false,
    isFavorite: false,
    artwork: 'linear-gradient(135deg, #180018 0%, #300030 50%, #100020 100%)',
    lyrics: `[00:00.00]Tokyo expressway under the purple twilight
[00:08.00]Reflections shimmering along the hood
[00:16.00]Solar winds charging across the night sky
[00:24.00]We traveled further than we ever could
[00:32.00]Neon shadows racing in the rearview mirror`
  }
];

export const INITIAL_PLAYLISTS: Playlist[] = [
  {
    id: 'pl-1',
    name: 'Night Drive Essentials',
    songIds: ['track-1', 'track-3', 'track-2'],
    createdAt: Date.now() - 86400000 * 4
  },
  {
    id: 'pl-2',
    name: 'Cyberpunk Focus',
    songIds: ['track-2', 'track-4', 'track-5', 'track-6'],
    createdAt: Date.now() - 86400000 * 2
  }
];
