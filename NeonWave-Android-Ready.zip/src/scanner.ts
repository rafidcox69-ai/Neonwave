import { Song } from './types';

export interface ScanReport {
  newSongsCount: number;
  categorizedFoldersCount: number;
  albumNames: string[];
  message: string;
  timestamp: number;
}

/**
 * Intelligently cleans and normalizes album names from metadata or filename cues.
 * Strips common noise like [FLAC], (Remastered 2024), Deluxe Edition, etc.
 */
export function cleanAlbumMetadata(album: string, fallbackTitle: string): string {
  if (!album || album.trim() === '' || album.toLowerCase() === 'unknown album' || album.toLowerCase() === 'device storage') {
    // Attempt to extract album from bracket cues in title e.g. "Song Name [Synth Odyssey]"
    const bracketMatch = /\[(.*?)\]|\((.*?)\)/.exec(fallbackTitle);
    if (bracketMatch) {
      const candidate = (bracketMatch[1] || bracketMatch[2]).trim();
      if (!candidate.toLowerCase().includes('feat') && !candidate.toLowerCase().includes('remix') && candidate.length > 2) {
        return candidate;
      }
    }
    return 'Singles & Standalone Tracks';
  }

  // Clean noise suffixes
  return album
    .replace(/\s*\[(FLAC|MP3|320kbps|Hi-Res|Lossless)\]/gi, '')
    .replace(/\s*\((Deluxe Edition|Remastered|Bonus Track Version)\)/gi, '')
    .trim();
}

/**
 * Categorizes a song into an intelligent folder name based on Album and Artist metadata.
 * Example outputs:
 * - "Kavinsky Pulse — Synthetic Overdrive"
 * - "Aethelgard 2088 — Megacity Run"
 * - "Singles & Standalone Tracks"
 */
export function getIntelligentAlbumFolder(song: { artist: string; album: string; title: string }): string {
  const cleanedAlbum = cleanAlbumMetadata(song.album, song.title);
  const artist = song.artist && song.artist.toLowerCase() !== 'unknown artist' ? song.artist.trim() : '';

  if (cleanedAlbum === 'Singles & Standalone Tracks') {
    return artist ? `${artist} (Singles)` : 'Singles & Standalone Tracks';
  }

  return artist ? `${artist} — ${cleanedAlbum}` : cleanedAlbum;
}

/**
 * Intelligently re-categorizes a list of songs into folders by album metadata.
 */
export function categorizeSongsByAlbumMetadata(songs: Song[]): {
  categorizedSongs: Song[];
  folderNames: string[];
  albumCount: number;
} {
  const foldersSet = new Set<string>();
  const albumsSet = new Set<string>();

  const categorizedSongs = songs.map((song) => {
    const intelligentFolder = getIntelligentAlbumFolder(song);
    foldersSet.add(intelligentFolder);
    const cleanedAlbum = cleanAlbumMetadata(song.album, song.title);
    if (cleanedAlbum !== 'Singles & Standalone Tracks') {
      albumsSet.add(cleanedAlbum);
    }
    return {
      ...song,
      folder: intelligentFolder,
      album: cleanedAlbum
    };
  });

  return {
    categorizedSongs,
    folderNames: Array.from(foldersSet),
    albumCount: albumsSet.size
  };
}

/**
 * Automated Directory Scanner using the File System Access API (showDirectoryPicker)
 * where supported by the browser/device, allowing users to scan entire device music folders.
 */
export async function scanDeviceMusicDirectory(): Promise<{
  discoveredSongs: Song[];
  report: ScanReport;
}> {
  if (!('showDirectoryPicker' in window)) {
    throw new Error('FileSystem Directory Picker is not supported in this browser. Please use the file import selector.');
  }

  try {
    const dirHandle = await (window as any).showDirectoryPicker({
      id: 'neonwave-music-folder',
      mode: 'read'
    });

    const discoveredSongs: Song[] = [];
    const supportedExtensions = ['.mp3', '.wav', '.flac', '.ogg', '.m4a', '.aac', '.opus'];

    async function traverseDirectory(handle: any, currentPath: string) {
      for await (const entry of handle.values()) {
        if (entry.kind === 'file') {
          const isAudio = supportedExtensions.some((ext) =>
            entry.name.toLowerCase().endsWith(ext)
          );
          if (isAudio) {
            const file = await entry.getFile();
            const url = URL.createObjectURL(file);
            const rawName = entry.name.replace(/\.[^/.]+$/, '');

            // Heuristic artist & title parser from filename: "Artist - Title" or "01 - Artist - Title"
            let artist = 'Local Artist';
            let title = rawName;
            let album = currentPath || 'Local Storage';

            const parts = rawName.split(' - ').map((p: string) => p.trim());
            if (parts.length >= 3) {
              // 01 - Artist - Title
              artist = parts[1];
              title = parts.slice(2).join(' - ');
            } else if (parts.length === 2) {
              // Artist - Title
              artist = parts[0];
              title = parts[1];
            }

            const cleanAlbum = cleanAlbumMetadata(album, title);
            const intelligentFolder = getIntelligentAlbumFolder({ artist, album: cleanAlbum, title });

            const song: Song = {
              id: 'device-' + Date.now() + '-' + Math.random().toString(36).substr(2, 6),
              title: title,
              artist: artist,
              album: cleanAlbum,
              duration: 180, // estimated until metadata loads
              url: url,
              folder: intelligentFolder,
              dateAdded: Date.now(),
              playCount: 0,
              isHidden: false,
              isFavorite: false,
              artwork: 'linear-gradient(135deg, #0e1017 0%, #1f2430 100%)',
              lyrics: `[00:00.00]${title}\n[00:03.00]${artist}\n[00:06.00]Album: ${cleanAlbum}`
            };

            discoveredSongs.push(song);
          }
        } else if (entry.kind === 'directory') {
          await traverseDirectory(entry, entry.name);
        }
      }
    }

    await traverseDirectory(dirHandle, dirHandle.name);

    const albumSet = new Set(discoveredSongs.map((s) => s.album));
    const folderSet = new Set(discoveredSongs.map((s) => s.folder));

    const report: ScanReport = {
      newSongsCount: discoveredSongs.length,
      categorizedFoldersCount: folderSet.size,
      albumNames: Array.from(albumSet),
      message: `Scanned and discovered ${discoveredSongs.length} tracks, categorized into ${folderSet.size} album folders.`,
      timestamp: Date.now()
    };

    return { discoveredSongs, report };
  } catch (err: any) {
    if (err.name === 'AbortError') {
      throw new Error('Scan cancelled by user.');
    }
    throw err;
  }
}
