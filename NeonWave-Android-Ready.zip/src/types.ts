export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  url: string; // audio source (data url, blob, or audio stream)
  artwork?: string;
  folder: string;
  dateAdded: number;
  playCount: number;
  isHidden: boolean;
  isFavorite: boolean;
  lyrics?: string; // LRC formatted string
  lastPlayed?: number; // timestamp of last playback
}

export interface Playlist {
  id: string;
  name: string;
  songIds: string[];
  createdAt: number;
}

export type MainTab = 'all' | 'folders' | 'playlists' | 'hidden' | 'most-played' | 'not-played';
export type SortOption = 'title-asc' | 'title-desc' | 'recent' | 'most-played';
export type ViewMode = 'list' | 'grid';
export type ActiveQueueId = 'A' | 'B';
export type RepeatMode = 'off' | 'all' | 'one';

export interface NeonTheme {
  id: 'cyan' | 'blue' | 'violet' | 'green';
  name: string;
  color: string;
  glowRgba: string;
}
