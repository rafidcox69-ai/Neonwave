import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  FolderArchive,
  Music,
  CheckCircle2,
  ExternalLink,
  X,
  Layers,
  ArrowDownToLine,
  Share2,
  Code2
} from 'lucide-react';
import { NeonTheme, Song } from './types';
import { usePWAInstall } from './usePWAInstall';
import JSZip from 'jszip';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: NeonTheme;
  songs: Song[];
}

export const DownloadModal: React.FC<DownloadModalProps> = ({
  isOpen,
  onClose,
  currentTheme,
  songs,
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [isZippingTracks, setIsZippingTracks] = useState(false);
  const [downloadSuccessToast, setDownloadSuccessToast] = useState<string | null>(null);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setDownloadSuccessToast(msg);
    setTimeout(() => setDownloadSuccessToast(null), 4000);
  };

  const handleDownloadTracksZip = async () => {
    try {
      setIsZippingTracks(true);
      const zip = new JSZip();
      const tracksFolder = zip.folder('NeonWave_Tracks')!;

      // Add songs and lyric files
      for (const song of songs) {
        if (song.url && song.url.startsWith('blob:')) {
          try {
            const resp = await fetch(song.url);
            const blob = await resp.blob();
            const filename = `${song.artist} - ${song.title}.wav`.replace(/[/\\?%*:|"<>]/g, '_');
            tracksFolder.file(filename, blob);
          } catch (e) {
            console.warn('Track fetch note:', e);
          }
        }
        if (song.lyrics) {
          const lyricFilename = `${song.artist} - ${song.title}.lrc`.replace(/[/\\?%*:|"<>]/g, '_');
          tracksFolder.file(lyricFilename, song.lyrics);
        }
      }

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'NeonWave_Offline_Synth_Tracks.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('Synthwave audio tracks downloaded!');
    } catch (err: any) {
      console.error(err);
      alert('Error bundling audio tracks: ' + err.message);
    } finally {
      setIsZippingTracks(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#0a0a10] border border-[#1b1b28] rounded-2xl p-5 shadow-2xl max-h-[90vh] overflow-y-auto text-zinc-300 relative">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#161622] mb-4">
          <div className="flex items-center gap-2">
            <div
              className="w-7 h-7 rounded-lg flex items-center justify-center border"
              style={{
                borderColor: currentTheme.color,
                backgroundColor: '#0c0c16',
                boxShadow: `0 0 10px ${currentTheme.glowRgba}`,
              }}
            >
              <Download className="w-4 h-4" style={{ color: currentTheme.color }} />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Download & Install NeonWave</h2>
              <p className="text-[10px] text-zinc-500">Android Offline Player • 100% Free • Zero Ads</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {downloadSuccessToast && (
          <div className="mb-3 p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-800/80 text-emerald-200 text-xs flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-none" />
            <span>{downloadSuccessToast}</span>
          </div>
        )}

        <div className="space-y-4 text-xs">
          {/* METHOD 1: Instant Android Phone Installation (PWA / WebAPK) */}
          <div className="p-3.5 rounded-xl border border-[#1a1a28] bg-[#0d0d16] relative overflow-hidden">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4" style={{ color: currentTheme.color }} />
                <h3 className="font-bold text-white text-xs">Method 1: Direct Android Phone App</h3>
              </div>
              <span
                className="text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded tracking-wider"
                style={{
                  backgroundColor: `${currentTheme.color}20`,
                  color: currentTheme.color,
                  border: `1px solid ${currentTheme.color}40`,
                }}
              >
                Recommended
              </span>
            </div>

            <p className="text-[11px] text-zinc-400 mb-3 leading-relaxed">
              Instantly installs NeonWave as a native standalone app on your <strong>Samsung Galaxy A06</strong> or other Android device. Runs 100% offline with custom app icon, full screen, and lock-screen playback controls.
            </p>

            {isInstalled ? (
              <div className="p-2.5 rounded-lg bg-[#121620] border border-cyan-900/60 text-cyan-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                <span>NeonWave is already installed as a standalone app!</span>
              </div>
            ) : isInstallable ? (
              <button
                onClick={async () => {
                  const ok = await install();
                  if (ok) showToast('App installed to your device successfully!');
                }}
                className="w-full py-2.5 px-3 rounded-xl font-extrabold text-xs text-black flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95"
                style={{
                  backgroundColor: currentTheme.color,
                  boxShadow: `0 0 15px ${currentTheme.glowRgba}`,
                }}
              >
                <ArrowDownToLine className="w-4 h-4 stroke-[2.5]" />
                Install to Device Home Screen
              </button>
            ) : isIOS ? (
              <div className="p-2.5 rounded-lg bg-[#14141e] border border-[#222234] text-[11px] text-zinc-300 space-y-1">
                <p className="font-semibold text-white flex items-center gap-1.5">
                  <Share2 className="w-3.5 h-3.5 text-blue-400" /> iOS Safari Steps:
                </p>
                <p>1. Tap the <strong>Share</strong> button in Safari toolbar.</p>
                <p>2. Scroll down and tap <strong>Add to Home Screen</strong>.</p>
              </div>
            ) : (
              <div className="p-2.5 rounded-lg bg-[#14141e] border border-[#222234] text-[11px] text-zinc-300 space-y-1">
                <p className="font-semibold text-white flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5" style={{ color: currentTheme.color }} /> Android Browser Steps:
                </p>
                <p>1. Tap browser menu (<strong>⋮</strong>) in the top-right.</p>
                <p>2. Select <strong>Install app</strong> or <strong>Add to Home screen</strong>.</p>
                <p className="text-zinc-500 text-[10px]">NeonWave will appear on your phone home screen with its neon disc icon.</p>
              </div>
            )}
          </div>

          {/* METHOD 2: Native Android Studio Project & APK Build (.ZIP) */}
          <div className="p-3.5 rounded-xl border border-[#1a1a28] bg-[#0d0d16]">
            <div className="flex items-center gap-2 mb-2">
              <Code2 className="w-4 h-4" style={{ color: currentTheme.color }} />
              <h3 className="font-bold text-white text-xs">Method 2: Android Studio APK Source</h3>
            </div>

            <p className="text-[11px] text-zinc-400 mb-3 leading-relaxed">
              Download the complete native Android project authored in <strong>Kotlin, Jetpack Compose, AndroidX Media3 (ExoPlayer), Room SQLite</strong>, and <strong>ContentObserver</strong>.
            </p>

            <a
              href="/api/download-android-zip"
              download="NeonWave-Android-Studio-Project.zip"
              className="w-full py-2.5 px-3 rounded-xl border border-zinc-700 bg-[#161624] hover:bg-[#1e1e30] font-bold text-white text-xs flex items-center justify-center gap-2 transition-all block text-center"
            >
              <FolderArchive className="w-4 h-4" style={{ color: currentTheme.color }} />
              Download Android Studio Project (.ZIP)
            </a>

            <div className="mt-2.5 p-2 rounded-lg bg-[#07070b] border border-[#151520] text-[10px] text-zinc-400 space-y-1">
              <p className="font-semibold text-zinc-300">How to generate .APK:</p>
              <p>1. Open the unzipped folder in <strong>Android Studio</strong>.</p>
              <p>2. Click <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong> (or run <code className="text-cyan-300">./gradlew assembleDebug</code>).</p>
              <p>3. Transfer the generated <code className="text-zinc-200">app-debug.apk</code> to your phone!</p>
            </div>
          </div>

          {/* METHOD 3: Full Project & Audio Tracks Downloads */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <a
              href="/api/download-project-zip"
              download="NeonWave-Complete-Project.zip"
              className="p-2.5 rounded-xl border border-[#1c1c28] bg-[#0d0d14] hover:bg-[#131320] text-center transition-all flex flex-col items-center justify-center gap-1.5"
            >
              <Layers className="w-4 h-4" style={{ color: currentTheme.color }} />
              <span className="font-bold text-white text-[11px]">Full Project ZIP</span>
              <span className="text-[9px] text-zinc-500">Android + Web sources</span>
            </a>

            <button
              onClick={handleDownloadTracksZip}
              disabled={isZippingTracks}
              className="p-2.5 rounded-xl border border-[#1c1c28] bg-[#0d0d14] hover:bg-[#131320] text-center transition-all flex flex-col items-center justify-center gap-1.5"
            >
              <Music className={`w-4 h-4 ${isZippingTracks ? 'animate-bounce' : ''}`} style={{ color: currentTheme.color }} />
              <span className="font-bold text-white text-[11px]">
                {isZippingTracks ? 'Bundling...' : 'Audio Tracks (.WAV)'}
              </span>
              <span className="text-[9px] text-zinc-500">6 Synthwave + Lyrics</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-[#14141e] text-center text-[10px] text-zinc-500">
          Target optimization: Samsung Galaxy A06 & all modern Android 8.0 - 15+ devices
        </div>
      </div>
    </div>
  );
};
